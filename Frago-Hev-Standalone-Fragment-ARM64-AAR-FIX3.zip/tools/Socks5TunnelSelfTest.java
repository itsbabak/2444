package net.typeblog.socks;

import android.net.VpnService;
import net.typeblog.socks.util.FragmentConfig;
import net.typeblog.socks.util.TlsHelloFragmenter;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Arrays;

/** JVM loopback smoke test for SOCKS5 CONNECT and UDP ASSOCIATE. */
public final class Socks5TunnelSelfTest {
    private static void readFully(InputStream in, byte[] buffer) throws Exception {
        int offset = 0;
        while (offset < buffer.length) {
            int count = in.read(buffer, offset, buffer.length - offset);
            if (count < 0) throw new EOFException("Unexpected SOCKS5 response EOF");
            offset += count;
        }
    }

    private static void authenticateNoAuth(InputStream in, OutputStream out) throws Exception {
        out.write(new byte[]{5, 1, 0});
        out.flush();
        byte[] response = new byte[2];
        readFully(in, response);
        if (response[0] != 5 || response[1] != 0) throw new AssertionError("SOCKS5 no-auth negotiation failed");
    }

    private static void testTcpConnect(int socksPort) throws Exception {
        byte[] payload = "frago-tcp-connect-check".getBytes("UTF-8");
        ServerSocket echoServer = new ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"));
        Thread echoThread = new Thread(() -> {
            try (Socket accepted = echoServer.accept()) {
                byte[] bytes = new byte[payload.length];
                int offset = 0;
                while (offset < bytes.length) {
                    int count = accepted.getInputStream().read(bytes, offset, bytes.length - offset);
                    if (count < 0) throw new EOFException("TCP echo input ended early");
                    offset += count;
                }
                accepted.getOutputStream().write(bytes);
                accepted.getOutputStream().flush();
            } catch (Exception e) { throw new RuntimeException(e); }
        }, "Frago-Test-TCP-Echo");
        echoThread.start();

        try (Socket client = new Socket("127.0.0.1", socksPort)) {
            client.setSoTimeout(5000);
            InputStream in = client.getInputStream();
            OutputStream out = client.getOutputStream();
            authenticateNoAuth(in, out);
            int port = echoServer.getLocalPort();
            out.write(new byte[]{5, 1, 0, 1, 127, 0, 0, 1,
                    (byte) (port >>> 8), (byte) port});
            out.flush();
            byte[] reply = new byte[10];
            readFully(in, reply);
            if (reply[1] != 0) throw new AssertionError("SOCKS5 CONNECT failed with reply=" + reply[1]);
            out.write(payload);
            out.flush();
            byte[] echoed = new byte[payload.length];
            readFully(in, echoed);
            if (!Arrays.equals(payload, echoed)) throw new AssertionError("TCP echo payload mismatch");
        } finally {
            echoServer.close();
        }
        echoThread.join(2000);
        System.out.println("PASS: SOCKS5 TCP CONNECT loopback echo");
    }


    private static void writeU16(ByteArrayOutputStream out, int value) {
        out.write((value >>> 8) & 0xff);
        out.write(value & 0xff);
    }

    private static byte[] makeClientHelloRecord() throws Exception {
        ByteArrayOutputStream sniList = new ByteArrayOutputStream();
        byte[] name = "example.com".getBytes("US-ASCII");
        sniList.write(0); // host_name
        writeU16(sniList, name.length);
        sniList.write(name);

        ByteArrayOutputStream sniData = new ByteArrayOutputStream();
        writeU16(sniData, sniList.size());
        sniData.write(sniList.toByteArray());

        ByteArrayOutputStream extensions = new ByteArrayOutputStream();
        writeU16(extensions, 0); // server_name extension
        writeU16(extensions, sniData.size());
        extensions.write(sniData.toByteArray());
        byte[] padding = new byte[520];
        writeU16(extensions, 21); // padding extension ensures a multi-record ClientHello
        writeU16(extensions, padding.length);
        extensions.write(padding);

        ByteArrayOutputStream body = new ByteArrayOutputStream();
        body.write(3); body.write(3); // legacy_version TLS 1.2
        body.write(new byte[32]); // random
        body.write(0); // session id length
        writeU16(body, 2); body.write(0x13); body.write(0x01); // TLS_AES_128_GCM_SHA256
        body.write(1); body.write(0); // one null compression method
        writeU16(body, extensions.size());
        body.write(extensions.toByteArray());

        ByteArrayOutputStream handshake = new ByteArrayOutputStream();
        handshake.write(1); // ClientHello
        int bodyLength = body.size();
        handshake.write((bodyLength >>> 16) & 0xff);
        handshake.write((bodyLength >>> 8) & 0xff);
        handshake.write(bodyLength & 0xff);
        handshake.write(body.toByteArray());
        byte[] payload = handshake.toByteArray();

        byte[] record = new byte[5 + payload.length];
        record[0] = 22;
        record[1] = 3;
        record[2] = 3;
        record[3] = (byte) (payload.length >>> 8);
        record[4] = (byte) payload.length;
        java.lang.System.arraycopy(payload, 0, record, 5, payload.length);
        return record;
    }

    private static byte[] readFragmentedHello(InputStream in, int expectedPayloadLength,
                                               ByteArrayOutputStream wire, int[] countOut) throws Exception {
        ByteArrayOutputStream payload = new ByteArrayOutputStream();
        int fragments = 0;
        while (payload.size() < expectedPayloadLength) {
            byte[] header = new byte[5];
            readFully(in, header);
            if ((header[0] & 0xff) != 22 || (header[1] & 0xff) != 3) {
                throw new AssertionError("Invalid TLS Fragment record header");
            }
            int length = ((header[3] & 0xff) << 8) | (header[4] & 0xff);
            if (length < 1 || length > 400) throw new AssertionError("Unexpected TLS fragment length=" + length);
            byte[] part = new byte[length];
            readFully(in, part);
            payload.write(part);
            if (wire != null) { wire.write(header); wire.write(part); }
            fragments++;
            if (payload.size() > expectedPayloadLength) throw new AssertionError("Fragment payload exceeded original length");
        }
        countOut[0] = fragments;
        return payload.toByteArray();
    }

    private static void testTlsFragmentPath(int socksPort) throws Exception {
        final byte[] originalRecord = makeClientHelloRecord();
        final int payloadLength = originalRecord.length - 5;
        if (!"example.com".equals(TlsHelloFragmenter.extractSni(originalRecord))) {
            throw new AssertionError("Synthetic TLS ClientHello SNI extraction failed");
        }
        ServerSocket echoServer = new ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"));
        Thread echoThread = new Thread(() -> {
            try (Socket accepted = echoServer.accept()) {
                ByteArrayOutputStream wire = new ByteArrayOutputStream();
                int[] count = new int[1];
                readFragmentedHello(accepted.getInputStream(), payloadLength, wire, count);
                if (count[0] < 2) throw new AssertionError("Frago did not create multiple TLS records");
                accepted.getOutputStream().write(wire.toByteArray());
                accepted.getOutputStream().flush();
            } catch (Exception e) { throw new RuntimeException(e); }
        }, "Frago-Test-TLS-Echo");
        echoThread.start();

        try (Socket client = new Socket("127.0.0.1", socksPort)) {
            client.setSoTimeout(10000);
            InputStream in = client.getInputStream();
            OutputStream out = client.getOutputStream();
            authenticateNoAuth(in, out);
            byte[] hostname = "localhost".getBytes("UTF-8");
            int port = echoServer.getLocalPort();
            out.write(new byte[]{5, 1, 0, 3, (byte) hostname.length});
            out.write(hostname);
            out.write(new byte[]{(byte) (port >>> 8), (byte) port});
            out.flush();
            byte[] reply = new byte[10];
            readFully(in, reply);
            if (reply[1] != 0) throw new AssertionError("SOCKS5 TLS test CONNECT failed: " + reply[1]);
            out.write(originalRecord);
            out.flush();

            int[] fragments = new int[1];
            byte[] reassembled = readFragmentedHello(in, payloadLength, null, fragments);
            if (fragments[0] < 2) throw new AssertionError("TLS ClientHello was not fragmented in the SOCKS TCP path");
            if (!Arrays.equals(Arrays.copyOfRange(originalRecord, 5, originalRecord.length), reassembled)) {
                throw new AssertionError("TLS fragment reassembly differs from original ClientHello payload");
            }
            System.out.println("PASS: TLS ClientHello fragmented in live SOCKS5 TCP path (" + fragments[0] + " TLS records)");
        } finally {
            echoServer.close();
        }
        echoThread.join(3000);
    }

    private static void testUdpAssociate(int socksPort) throws Exception {
        DatagramSocket echoServer = new DatagramSocket(0, InetAddress.getByName("127.0.0.1"));
        Thread echoThread = new Thread(() -> {
            byte[] bytes = new byte[2048];
            try {
                DatagramPacket packet = new DatagramPacket(bytes, bytes.length);
                echoServer.receive(packet);
                echoServer.send(new DatagramPacket(packet.getData(), packet.getLength(),
                        packet.getAddress(), packet.getPort()));
            } catch (Exception e) { throw new RuntimeException(e); }
        }, "Frago-Test-UDP-Echo");
        echoThread.start();

        byte[] payload = "frago-udp-associate-check".getBytes("UTF-8");
        try (Socket control = new Socket("127.0.0.1", socksPort);
             DatagramSocket udpClient = new DatagramSocket()) {
            control.setSoTimeout(5000);
            udpClient.setSoTimeout(5000);
            InputStream in = control.getInputStream();
            OutputStream out = control.getOutputStream();
            authenticateNoAuth(in, out);
            out.write(new byte[]{5, 3, 0, 1, 0, 0, 0, 0, 0, 0});
            out.flush();
            byte[] reply = new byte[10];
            readFully(in, reply);
            if (reply[1] != 0 || reply[3] != 1) throw new AssertionError("SOCKS5 UDP ASSOCIATE failed");
            int relayPort = ((reply[8] & 0xff) << 8) | (reply[9] & 0xff);
            int echoPort = echoServer.getLocalPort();
            ByteArrayOutputStream packet = new ByteArrayOutputStream();
            packet.write(new byte[]{0, 0, 0, 1, 127, 0, 0, 1,
                    (byte) (echoPort >>> 8), (byte) echoPort});
            packet.write(payload);
            byte[] request = packet.toByteArray();
            udpClient.send(new DatagramPacket(request, request.length,
                    InetAddress.getByName("127.0.0.1"), relayPort));

            byte[] response = new byte[2048];
            DatagramPacket received = new DatagramPacket(response, response.length);
            udpClient.receive(received);
            int p = 3;
            int atyp = response[p++] & 0xff;
            int addressLength = atyp == 1 ? 4 : atyp == 4 ? 16 : -1;
            if (addressLength < 0) throw new AssertionError("Invalid SOCKS5 UDP response ATYP");
            p += addressLength + 2;
            byte[] echoed = Arrays.copyOfRange(response, p, received.getLength());
            if (!Arrays.equals(payload, echoed)) throw new AssertionError("UDP echo payload mismatch");
        } finally {
            echoServer.close();
        }
        echoThread.join(2000);
        System.out.println("PASS: SOCKS5 UDP ASSOCIATE loopback echo");
    }

    public static void main(String[] args) throws Exception {
        FragmentConfig config = FragmentConfig.parse(null);
        VpnService vpn = new VpnService();
        DnsProxy dns = new DnsProxy(vpn, config);
        if (!dns.start()) throw new AssertionError("DNS resolver did not start");
        FragmentSocks5Engine engine = new FragmentSocks5Engine(vpn, config, dns);
        if (!engine.start()) throw new AssertionError("SOCKS5 server did not start");
        try {
            testTcpConnect(config.socksPort);
            testTlsFragmentPath(config.socksPort);
            testUdpAssociate(config.socksPort);
        } finally {
            engine.stop();
            dns.stop();
        }
    }
}
