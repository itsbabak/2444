package net.typeblog.socks.util;

import java.io.OutputStream;
import java.util.concurrent.ThreadLocalRandom;

/** Xray freedom-style packets=tlshello fragmentation without a proxy-core dependency. */
public final class TlsHelloFragmenter {
    private TlsHelloFragmenter() { }

    public static boolean isClientHelloRecord(byte[] record) {
        return record != null && record.length >= 6
                && (record[0] & 0xff) == 22
                && (record[1] & 0xff) == 3
                && (record[5] & 0xff) == 1;
    }

    /**
     * Splits the first TLS Handshake record payload into multiple separate TLS
     * Handshake records. Record headers are recreated with per-fragment lengths,
     * matching Xray's legacy freedom fragment behavior for packets="tlshello".
     * Returns the number of records written; returns zero when input is invalid.
     */
    public static int writeFragments(OutputStream out, byte[] record,
                                     int minLength, int maxLength,
                                     int minIntervalMs, int maxIntervalMs) throws Exception {
        if (!isClientHelloRecord(record)) return 0;
        int recordLength = ((record[3] & 0xff) << 8) | (record[4] & 0xff);
        if (recordLength != record.length - 5 || recordLength < 1) {
            out.write(record);
            out.flush();
            return 0;
        }

        int offset = 0;
        int chunks = 0;
        while (offset < recordLength) {
            int chunkSize = minLength + ThreadLocalRandom.current().nextInt(
                    Math.max(1, maxLength - minLength + 1));
            int count = Math.min(chunkSize, recordLength - offset);

            byte[] fragmentRecord = new byte[5 + count];
            fragmentRecord[0] = record[0];
            fragmentRecord[1] = record[1];
            fragmentRecord[2] = record[2];
            fragmentRecord[3] = (byte) ((count >>> 8) & 0xff);
            fragmentRecord[4] = (byte) (count & 0xff);
            java.lang.System.arraycopy(record, 5 + offset, fragmentRecord, 5, count);
            out.write(fragmentRecord);
            out.flush();
            offset += count;
            chunks++;

            if (offset < recordLength && maxIntervalMs > 0) {
                int delay = minIntervalMs + ThreadLocalRandom.current().nextInt(
                        Math.max(1, maxIntervalMs - minIntervalMs + 1));
                if (delay > 0) Thread.sleep(delay);
            }
        }
        return chunks;
    }

    /** Extract SNI from a single-record ClientHello; null means unavailable. */
    public static String extractSni(byte[] record) {
        try {
            if (!isClientHelloRecord(record)) return null;
            int recordEnd = Math.min(record.length,
                    5 + (((record[3] & 0xff) << 8) | (record[4] & 0xff)));
            int p = 5;
            if (p + 4 > recordEnd || (record[p] & 0xff) != 1) return null;
            int handshakeLength = ((record[p + 1] & 0xff) << 16)
                    | ((record[p + 2] & 0xff) << 8) | (record[p + 3] & 0xff);
            p += 4;
            int handshakeEnd = Math.min(recordEnd, p + handshakeLength);
            if (p + 34 > handshakeEnd) return null;
            p += 34; // legacy_version + random
            int sessionIdLength = record[p++] & 0xff;
            p += sessionIdLength;
            if (p + 2 > handshakeEnd) return null;
            int cipherLength = ((record[p] & 0xff) << 8) | (record[p + 1] & 0xff);
            p += 2 + cipherLength;
            if (p >= handshakeEnd) return null;
            int compressionLength = record[p++] & 0xff;
            p += compressionLength;
            if (p + 2 > handshakeEnd) return null;
            int extensionsLength = ((record[p] & 0xff) << 8) | (record[p + 1] & 0xff);
            p += 2;
            int extensionsEnd = Math.min(handshakeEnd, p + extensionsLength);
            while (p + 4 <= extensionsEnd) {
                int type = ((record[p] & 0xff) << 8) | (record[p + 1] & 0xff);
                int length = ((record[p + 2] & 0xff) << 8) | (record[p + 3] & 0xff);
                p += 4;
                if (p + length > extensionsEnd) return null;
                if (type == 0 && length >= 5) {
                    int listLength = ((record[p] & 0xff) << 8) | (record[p + 1] & 0xff);
                    int q = p + 2;
                    int listEnd = Math.min(p + length, q + listLength);
                    while (q + 3 <= listEnd) {
                        int nameType = record[q++] & 0xff;
                        int nameLength = ((record[q] & 0xff) << 8) | (record[q + 1] & 0xff);
                        q += 2;
                        if (q + nameLength > listEnd) return null;
                        if (nameType == 0) return new String(record, q, nameLength, "US-ASCII");
                        q += nameLength;
                    }
                    return null;
                }
                p += length;
            }
        } catch (Exception ignored) { }
        return null;
    }
}
