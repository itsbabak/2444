package net.typeblog.socks;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.VpnService;
import android.util.Log;

import net.typeblog.socks.util.FragmentConfig;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.URL;
import java.net.URLConnection;
import java.net.HttpURLConnection;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Small DNS forwarder supporting the DoH and hosts fields used by Frago JSON. */
final class DnsProxy {
    private static final String TAG = "FragoDNS";
    private static final int MAX_DNS_PACKET = 8192;
    private static final int TIMEOUT_MS = 9000;

    private final VpnService vpn;
    private final FragmentConfig config;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private final ExecutorService workers = Executors.newFixedThreadPool(4);
    private DatagramSocket listener;
    private Thread loopThread;
    private Network underlyingNetwork;

    DnsProxy(VpnService vpn, FragmentConfig config) {
        this.vpn = vpn;
        this.config = config;
    }

    boolean start() {
        try {
            underlyingNetwork = findUnderlyingNetwork();
            listener = new DatagramSocket(null);
            listener.setReuseAddress(true);
            listener.bind(new InetSocketAddress("0.0.0.0", FragmentConfig.DNS_GATEWAY_PORT));
            running.set(true);
            loopThread = new Thread(() -> {
                byte[] buffer = new byte[MAX_DNS_PACKET];
                while (running.get()) {
                    try {
                        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                        listener.receive(packet);
                        byte[] query = new byte[packet.getLength()];
                        java.lang.System.arraycopy(packet.getData(), packet.getOffset(), query, 0, packet.getLength());
                        InetAddress clientAddress = packet.getAddress();
                        int clientPort = packet.getPort();
                        workers.execute(() -> answer(query, clientAddress, clientPort));
                    } catch (Exception e) {
                        if (running.get()) Log.w(TAG, "DNS receive failed", e);
                    }
                }
            }, "Frago-DNS-UDP");
            loopThread.start();
            Log.i(TAG, "DNS gateway listening on UDP/" + FragmentConfig.DNS_GATEWAY_PORT
                    + (config.dohUrl.isEmpty() ? ", upstream=" + config.dnsServer + ":" + config.dnsPort
                    : ", DoH=" + config.dohUrl));
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Cannot start DNS gateway", e);
            stop();
            return false;
        }
    }

    private void answer(byte[] query, InetAddress clientAddress, int clientPort) {
        DnsQuestion question = parseQuestion(query);
        if (question == null) return;
        byte[] response;
        try {
            List<String> override = config.findHostOverride(question.name);
            if (override != null) {
                response = makeHostResponse(query, question, override);
            } else if (config.useIpv4Only && question.type == 28) {
                response = makeEmptyResponse(query, question, 0);
            } else if (!config.dohUrl.isEmpty()) {
                response = queryDoh(query);
                if (response != null && response.length >= 2) {
                    response[0] = query[0];
                    response[1] = query[1];
                }
            } else {
                response = queryPlainDns(query);
            }
            if (response == null || response.length == 0) response = makeEmptyResponse(query, question, 2);
        } catch (Exception e) {
            Log.w(TAG, "DNS query failed for " + question.name, e);
            try { response = makeEmptyResponse(query, question, 2); }
            catch (Exception ignored) { return; }
        }
        try {
            DatagramPacket reply = new DatagramPacket(response, response.length, clientAddress, clientPort);
            synchronized (listener) {
                if (running.get() && listener != null && !listener.isClosed()) listener.send(reply);
            }
        } catch (Exception e) {
            if (running.get()) Log.w(TAG, "DNS response send failed", e);
        }
    }

    private byte[] queryDoh(byte[] query) throws Exception {
        URL url = java.net.URI.create(config.dohUrl).toURL();
        URLConnection raw = underlyingNetwork != null
                ? underlyingNetwork.openConnection(url) : url.openConnection();
        if (!(raw instanceof HttpURLConnection)) throw new IllegalArgumentException("DoH URL must be HTTPS");
        HttpURLConnection connection = (HttpURLConnection) raw;
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(TIMEOUT_MS);
        connection.setReadTimeout(TIMEOUT_MS);
        connection.setDoOutput(true);
        connection.setInstanceFollowRedirects(true);
        connection.setFixedLengthStreamingMode(query.length);
        connection.setRequestProperty("User-Agent", "FragoDNS/1.0");
        connection.setRequestProperty("Content-Type", "application/dns-message");
        connection.setRequestProperty("Accept", "application/dns-message");
        connection.setUseCaches(false);
        try {
            try (OutputStream out = connection.getOutputStream()) { out.write(query); }
            int status = connection.getResponseCode();
            InputStream input = status >= 200 && status < 300
                    ? connection.getInputStream() : connection.getErrorStream();
            if (input == null) throw new IllegalStateException("DoH HTTP status " + status);
            try (InputStream in = input; ByteArrayOutputStream bytes = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[1024];
                int count;
                while ((count = in.read(buffer)) != -1) {
                    bytes.write(buffer, 0, count);
                    if (bytes.size() > MAX_DNS_PACKET) throw new IllegalStateException("DoH response too large");
                }
                if (status < 200 || status >= 300) throw new IllegalStateException("DoH HTTP status " + status);
                return bytes.toByteArray();
            }
        } finally {
            connection.disconnect();
        }
    }

    private byte[] queryPlainDns(byte[] query) throws Exception {
        DatagramSocket upstream = new DatagramSocket();
        try {
            if (!vpn.protect(upstream)) throw new IllegalStateException("VpnService.protect(DNS) failed");
            upstream.setSoTimeout(TIMEOUT_MS);
            InetAddress server = InetAddress.getByName(config.dnsServer);
            upstream.send(new DatagramPacket(query, query.length, server, config.dnsPort));
            byte[] buffer = new byte[MAX_DNS_PACKET];
            DatagramPacket response = new DatagramPacket(buffer, buffer.length);
            upstream.receive(response);
            byte[] result = new byte[response.getLength()];
            java.lang.System.arraycopy(response.getData(), response.getOffset(), result, 0, response.getLength());
            return result;
        } finally {
            upstream.close();
        }
    }

    private static final class DnsQuestion {
        final String name;
        final int type;
        final int questionEnd;
        DnsQuestion(String name, int type, int questionEnd) {
            this.name = name;
            this.type = type;
            this.questionEnd = questionEnd;
        }
    }

    private static DnsQuestion parseQuestion(byte[] query) {
        if (query == null || query.length < 17 || readU16(query, 4) < 1) return null;
        StringBuilder name = new StringBuilder();
        int p = 12;
        int consumedEnd = -1;
        int jumps = 0;
        boolean jumped = false;
        while (p < query.length && jumps++ < 32) {
            int len = query[p] & 0xff;
            if (len == 0) {
                if (!jumped) consumedEnd = p + 1;
                p++;
                break;
            }
            if ((len & 0xc0) == 0xc0) {
                if (p + 1 >= query.length) return null;
                int pointer = ((len & 0x3f) << 8) | (query[p + 1] & 0xff);
                if (!jumped) consumedEnd = p + 2;
                p = pointer;
                jumped = true;
                continue;
            }
            if ((len & 0xc0) != 0 || len > 63 || p + 1 + len > query.length) return null;
            if (name.length() > 0) name.append('.');
            name.append(new String(query, p + 1, len, java.nio.charset.Charset.forName("US-ASCII")));
            p += 1 + len;
        }
        if (consumedEnd < 0) consumedEnd = p;
        if (consumedEnd + 4 > query.length) return null;
        return new DnsQuestion(name.toString().toLowerCase(java.util.Locale.ROOT),
                readU16(query, consumedEnd), consumedEnd + 4);
    }

    private static byte[] makeHostResponse(byte[] query, DnsQuestion q, List<String> addresses) throws Exception {
        java.io.ByteArrayOutputStream out = responseHeaderAndQuestion(query, q, 0, 0);
        int answers = 0;
        if (q.type == 1) {
            for (String address : addresses) {
                byte[] ip = parseIpv4(address);
                if (ip == null) continue;
                out.write(new byte[]{(byte) 0xc0, 0x0c, 0, 1, 0, 1, 0, 0, 0, 60, 0, 4});
                out.write(ip);
                answers++;
            }
        }
        byte[] result = out.toByteArray();
        writeU16(result, 6, answers);
        return result;
    }

    private static byte[] makeEmptyResponse(byte[] query, DnsQuestion q, int rcode) throws Exception {
        return responseHeaderAndQuestion(query, q, 0, rcode).toByteArray();
    }

    private static java.io.ByteArrayOutputStream responseHeaderAndQuestion(byte[] query, DnsQuestion q,
                                                                            int answers, int rcode) throws Exception {
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        out.write(query, 0, 2);
        int requestFlags = readU16(query, 2);
        int flags = 0x8000 | (requestFlags & 0x7900) | 0x0080 | (rcode & 0x0f);
        out.write((flags >>> 8) & 0xff);
        out.write(flags & 0xff);
        out.write(0); out.write(1); // one question
        out.write((answers >>> 8) & 0xff); out.write(answers & 0xff);
        out.write(0); out.write(0); // authority records
        out.write(0); out.write(0); // additional records
        out.write(query, 12, q.questionEnd - 12);
        return out;
    }

    private static byte[] parseIpv4(String ip) {
        String[] parts = ip.split("\\.");
        if (parts.length != 4) return null;
        byte[] result = new byte[4];
        try {
            for (int i = 0; i < 4; i++) {
                int value = Integer.parseInt(parts[i]);
                if (value < 0 || value > 255) return null;
                result[i] = (byte) value;
            }
            return result;
        } catch (Exception e) { return null; }
    }

    private Network findUnderlyingNetwork() {
        try {
            ConnectivityManager manager = (ConnectivityManager) vpn.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (manager == null) return null;
            Network fallback = null;
            for (Network network : manager.getAllNetworks()) {
                NetworkCapabilities caps = manager.getNetworkCapabilities(network);
                if (caps == null || caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue;
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                        || caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                        || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) return network;
                if (fallback == null) fallback = network;
            }
            return fallback;
        } catch (Exception e) {
            Log.w(TAG, "Could not locate underlying network for DoH", e);
            return null;
        }
    }

    private static int readU16(byte[] data, int offset) {
        return ((data[offset] & 0xff) << 8) | (data[offset + 1] & 0xff);
    }

    private static void writeU16(byte[] data, int offset, int value) {
        data[offset] = (byte) ((value >>> 8) & 0xff);
        data[offset + 1] = (byte) (value & 0xff);
    }

    void stop() {
        running.set(false);
        if (listener != null) listener.close();
        workers.shutdownNow();
    }
}
