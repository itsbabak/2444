package hev.htproxy;

/** JNI bridge bundled with the upstream HevSocks5Tunnel Android shared library. */
public final class TProxyService {
    private TProxyService() { }

    public static native boolean TProxyStartService(String configPath, int tunFd);
    public static native boolean TProxyStopService();
    public static native boolean TProxyIsRunning();
    public static native long[] TProxyGetStats();

    static {
        System.loadLibrary("hev-socks5-tunnel");
    }
}
