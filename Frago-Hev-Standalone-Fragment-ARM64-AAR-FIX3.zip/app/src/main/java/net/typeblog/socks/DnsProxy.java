package net.typeblog.socks;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.VpnService;
import android.util.Log;

import net.typeblog.socks.util.FragmentConfig;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/** DNS resolver for the imported DoH, UseIPv4 and hosts settings. */
final class DnsProxy {
    private static final String TAG = "FragoDNS";
    private static final int MAX_DNS_PACKET = 8192;
    private static final int TIMEOUT_MS = 9000;
    private static final long CACHE_TTL_MS = 60_000L;

    private final VpnService vpn;
    private final FragmentConfig config;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private final ConcurrentHashMap<String, CacheEntry> ipv4Cache = new ConcurrentHashMap<>();
    private volatile Network underlyingNetwork;
    private final Network preferredUnderlyingNetwork;
    private volatile int queryId = 0x4f31;

    private static final class CacheEntry {
        final List<InetAddress> addresses;
        final long expiresAt;
        CacheEntry(List<InetAddress> addresses) {
            this.addresses = addresses;
            this.expiresAt = java.lang.System.currentTimeMillis() + CACHE_TTL_MS;
        }
    }

    DnsProxy(VpnService vpn, FragmentConfig config) {
        this(vpn, config, null);
    }

    DnsProxy(VpnService vpn, FragmentConfig config, Network preferredUnderlyingNetwork) {
        this.vpn = vpn;
        this.config = config;
        this.preferredUnderlyingNetwork = preferredUnderlyingNetwork;
    }

    /** Initializes the selected physical network. DNS requests are resolved on demand. */
    boolean start() {
        underlyingNetwork = preferredUnderlyingNetwork != null
                ? preferredUnderlyingNetwork : findUnderlyingNetwork();
        running.set(true);
        Log.i(TAG, "DNS resolver ready; upstream=" + (config.dohUrl.isEmpty()
                ? config.dnsServer + ":" + config.dnsPort : config.dohUrl)
                + ", queryStrategy=" + (config.useIpv4Only ? "UseIPv4" : "UseIPv4v6")
                + ", physicalNetwork=" + underlyingNetwork);
        return true;
    }

    /** Resolves an RFC 1035 DNS message using hosts overrides, DoH or configured plain DNS. */
    byte[] resolveDnsMessage(byte[] query) {
        DnsQuestion question = parseQuestion(query);
        if (!running.get() || question == null) return null;
        try {
            List<String> override = config.findHostOverride(question.name);
            byte[] response;
            if (override != null) {
                response = makeHostResponse(query, question, override);
            } else if (config.useIpv4Only && question.type == 28) {
                response = makeEmptyResponse(query, question, 0);
            } else if (!config.dohUrl.isEmpty()) {
                response = queryDoh(query);
                if (response != null && response.length >= 2) {
                    response[0] = query[0];
                    response[1] = query[1];
                }
            } else {
                response = queryPlainDns(query);
                if (response != null && response.length >= 2) {
                    response[0] = query[0];
                    response[1] = query[1];
                }
            }
            if (response == null || response.length == 0) return makeEmptyResponse(query, question, 2);
            Log.d(TAG, "Resolved " + question.name + " type=" + question.type
                    + " via " + (override != null ? "hosts" : (!config.dohUrl.isEmpty() ? "DoH" : "DNS")));
            return response;
        } catch (Exception e) {
            Log.w(TAG, "DNS query failed for " + question.name, e);
            try { return makeEmptyResponse(query, question, 2); }
            catch (Exception ignored) { return null; }
        }
    }

    /** Resolves a hostname using this app's configured DNS path, never the VPN-routed system resolver. */
    List<InetAddress> resolveIpv4(String host) {
        if (host == null || host.trim().isEmpty()) return Collections.emptyList();
        String normalized = host.trim().toLowerCase(Locale.ROOT);
        if (isIpv4Literal(normalized)) {
            try { return Collections.singletonList(InetAddress.getByName(normalized)); }
            catch (Exception ignored) { return Collections.emptyList(); }
        }
        CacheEntry cached = ipv4Cache.get(normalized);
        if (cached != null && cached.expiresAt > java.lang.System.currentTimeMillis()) {
            return cached.addresses;
        }
        List<String> overrides = config.findHostOverride(normalized);
        List<InetAddress> result = new ArrayList<>();
        try {
            if (overrides != null) {
                for (String address : overrides) result.add(InetAddress.getByName(address));
            } else {
                byte[] query = makeQuery(normalized, 1);
                byte[] response = resolveDnsMessage(query);
                if (response != null) result.addAll(extractIpv4Answers(response));
            }
        } catch (Exception e) {
            Log.w(TAG, "Hostname resolution failed: " + normalized, e);
        }
        List<InetAddress> immutable = Collections.unmodifiableList(result);
        if (!result.isEmpty()) ipv4Cache.put(normalized, new CacheEntry(immutable));
        return immutable;
    }

    private byte[] queryDoh(byte[] query) throws Exception {
        URL url = new URL(config.dohUrl);
        Network selected = underlyingNetwork;
        URLConnection raw = selected != null ? selected.openConnection(url) : url.openConnection();
        if (!(raw instanceof HttpURLConnection)) throw new IllegalArgumentException("DoH URL must be HTTPS");
        HttpURLConnection connection = (HttpURLConnection) raw;
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(TIMEOUT_MS);
        connection.setReadTimeout(TIMEOUT_MS);
        connection.setDoOutput(true);
        connection.setInstanceFollowRedirects(true);
        connection.setFixedLengthStreamingMode(query.length);
        connection.setRequestProperty("User-Agent", "FragoDNS/2.0");
        connection.setRequestProperty("Content-Type", "application/dns-message");
        connection.setRequestProperty("Accept", "application/dns-message");
        connection.setUseCaches(false);
        try {
            try (OutputStream out = connection.getOutputStream()) { out.write(query); }
            int status = connection.getResponseCode();
            InputStream input = status >= 200 && status < 300
                    ? connection.getInputStream() : connection.getErrorStream();
            if (input == null) throw new IllegalStateException("DoH HTTP status " + status);
            try (InputStream in = input; ByteArrayOutputStream bytes = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[1024];
                int count;
                while ((count = in.read(buffer)) != -1) {
                    bytes.write(buffer, 0, count);
                    if (bytes.size() > MAX_DNS_PACKET) throw new IllegalStateException("DoH response too large");
                }
                if (status < 200 || status >= 300) throw new IllegalStateException("DoH HTTP status " + status);
                return bytes.toByteArray();
            }
        } finally {
            connection.disconnect();
        }
    }

    private byte[] queryPlainDns(byte[] query) throws Exception {
        DatagramSocket upstream = new DatagramSocket();
        try {
            if (!vpn.protect(upstream)) throw new IllegalStateException("VpnService.protect(DNS) failed");
            upstream.setSoTimeout(TIMEOUT_MS);
            InetAddress server = InetAddress.getByName(config.dnsServer);
            upstream.send(new DatagramPacket(query, query.length, server, config.dnsPort));
            byte[] buffer = new byte[MAX_DNS_PACKET];
            DatagramPacket response = new DatagramPacket(buffer, buffer.length);
            upstream.receive(response);
            byte[] result = new byte[response.getLength()];
            java.lang.System.arraycopy(response.getData(), response.getOffset(), result, 0, response.getLength());
            return result;
        } finally {
            upstream.close();
        }
    }

    private synchronized byte[] makeQuery(String host, int type) throws Exception {
        String clean = host.endsWith(".") ? host.substring(0, host.length() - 1) : host;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int id = (++queryId) & 0xffff;
        out.write((id >>> 8) & 0xff); out.write(id & 0xff);
        out.write(0x01); out.write(0x00); // recursion desired
        out.write(0); out.write(1); // QDCOUNT
        out.write(0); out.write(0); out.write(0); out.write(0); out.write(0); out.write(0);
        for (String label : clean.split("\\.")) {
            byte[] bytes = label.getBytes(StandardCharsets.US_ASCII);
            if (bytes.length < 1 || bytes.length > 63) throw new IllegalArgumentException("Invalid DNS label");
            out.write(bytes.length); out.write(bytes);
        }
        out.write(0);
        out.write((type >>> 8) & 0xff); out.write(type & 0xff);
        out.write(0); out.write(1); // IN
        return out.toByteArray();
    }

    private static final class DnsQuestion {
        final String name;
        final int type;
        final int questionEnd;
        DnsQuestion(String name, int type, int questionEnd) {
            this.name = name;
            this.type = type;
            this.questionEnd = questionEnd;
        }
    }

    private static DnsQuestion parseQuestion(byte[] query) {
        if (query == null || query.length < 17 || readU16(query, 4) < 1) return null;
        StringBuilder name = new StringBuilder();
        int p = 12;
        int consumedEnd = -1;
        int jumps = 0;
        boolean jumped = false;
        while (p < query.length && jumps++ < 32) {
            int len = query[p] & 0xff;
            if (len == 0) {
                if (!jumped) consumedEnd = p + 1;
                p++;
                break;
            }
            if ((len & 0xc0) == 0xc0) {
                if (p + 1 >= query.length) return null;
                int pointer = ((len & 0x3f) << 8) | (query[p + 1] & 0xff);
                if (pointer >= query.length) return null;
                if (!jumped) consumedEnd = p + 2;
                p = pointer;
                jumped = true;
                continue;
            }
            if ((len & 0xc0) != 0 || len > 63 || p + 1 + len > query.length) return null;
            if (name.length() > 0) name.append('.');
            name.append(new String(query, p + 1, len, StandardCharsets.US_ASCII));
            p += 1 + len;
        }
        if (consumedEnd < 0) consumedEnd = p;
        if (consumedEnd + 4 > query.length) return null;
        return new DnsQuestion(name.toString().toLowerCase(Locale.ROOT),
                readU16(query, consumedEnd), consumedEnd + 4);
    }

    private static List<InetAddress> extractIpv4Answers(byte[] response) {
        List<InetAddress> addresses = new ArrayList<>();
        try {
            if (response == null || response.length < 12 || (readU16(response, 2) & 0x8000) == 0) return addresses;
            int questions = readU16(response, 4);
            int answers = readU16(response, 6);
            int p = 12;
            for (int i = 0; i < questions; i++) {
                p = skipDnsName(response, p);
                if (p < 0 || p + 4 > response.length) return addresses;
                p += 4;
            }
            for (int i = 0; i < answers; i++) {
                p = skipDnsName(response, p);
                if (p < 0 || p + 10 > response.length) break;
                int type = readU16(response, p);
                int clazz = readU16(response, p + 2);
                int dataLength = readU16(response, p + 8);
                p += 10;
                if (dataLength < 0 || p + dataLength > response.length) break;
                if (type == 1 && clazz == 1 && dataLength == 4) {
                    byte[] ip = new byte[4];
                    java.lang.System.arraycopy(response, p, ip, 0, 4);
                    addresses.add(InetAddress.getByAddress(ip));
                }
                p += dataLength;
            }
        } catch (Exception ignored) { }
        return addresses;
    }

    private static int skipDnsName(byte[] data, int offset) {
        int p = offset;
        int steps = 0;
        while (p < data.length && steps++ < 128) {
            int len = data[p] & 0xff;
            if (len == 0) return p + 1;
            if ((len & 0xc0) == 0xc0) return p + 2 <= data.length ? p + 2 : -1;
            if ((len & 0xc0) != 0 || len > 63 || p + 1 + len > data.length) return -1;
            p += 1 + len;
        }
        return -1;
    }

    private static byte[] makeHostResponse(byte[] query, DnsQuestion q, List<String> addresses) throws Exception {
        ByteArrayOutputStream out = responseHeaderAndQuestion(query, q, 0, 0);
        int answers = 0;
        if (q.type == 1) {
            for (String address : addresses) {
                byte[] ip = parseIpv4(address);
                if (ip == null) continue;
                out.write(new byte[]{(byte) 0xc0, 0x0c, 0, 1, 0, 1, 0, 0, 0, 60, 0, 4});
                out.write(ip);
                answers++;
            }
        }
        byte[] result = out.toByteArray();
        writeU16(result, 6, answers);
        return result;
    }

    private static byte[] makeEmptyResponse(byte[] query, DnsQuestion q, int rcode) throws Exception {
        return responseHeaderAndQuestion(query, q, 0, rcode).toByteArray();
    }

    private static ByteArrayOutputStream responseHeaderAndQuestion(byte[] query, DnsQuestion q,
                                                                    int answers, int rcode) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(query, 0, 2);
        int requestFlags = readU16(query, 2);
        int flags = 0x8000 | (requestFlags & 0x7900) | 0x0080 | (rcode & 0x0f);
        out.write((flags >>> 8) & 0xff);
        out.write(flags & 0xff);
        out.write(0); out.write(1);
        out.write((answers >>> 8) & 0xff); out.write(answers & 0xff);
        out.write(0); out.write(0); out.write(0); out.write(0);
        out.write(query, 12, q.questionEnd - 12);
        return out;
    }

    private static byte[] parseIpv4(String ip) {
        String[] parts = ip.split("\\.");
        if (parts.length != 4) return null;
        byte[] result = new byte[4];
        try {
            for (int i = 0; i < 4; i++) {
                int value = Integer.parseInt(parts[i]);
                if (value < 0 || value > 255) return null;
                result[i] = (byte) value;
            }
            return result;
        } catch (Exception e) { return null; }
    }

    private static boolean isIpv4Literal(String value) {
        return value != null && value.matches("[0-9]{1,3}(\\.[0-9]{1,3}){3}");
    }

    private Network findUnderlyingNetwork() {
        try {
            ConnectivityManager manager = (ConnectivityManager) vpn.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (manager == null) return null;
            Network fallback = null;
            for (Network network : manager.getAllNetworks()) {
                NetworkCapabilities caps = manager.getNetworkCapabilities(network);
                if (caps == null || caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue;
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                        || caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                        || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) return network;
                if (fallback == null) fallback = network;
            }
            return fallback;
        } catch (Exception e) {
            Log.w(TAG, "Could not locate underlying network for DoH", e);
            return null;
        }
    }

    private static int readU16(byte[] data, int offset) {
        return ((data[offset] & 0xff) << 8) | (data[offset + 1] & 0xff);
    }

    private static void writeU16(byte[] data, int offset, int value) {
        data[offset] = (byte) ((value >>> 8) & 0xff);
        data[offset + 1] = (byte) (value & 0xff);
    }

    void stop() {
        running.set(false);
        ipv4Cache.clear();
    }
}
