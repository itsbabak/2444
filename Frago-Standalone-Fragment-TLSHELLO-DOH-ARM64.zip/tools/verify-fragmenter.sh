#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
javac -d "$TMP" \
  "$ROOT/app/src/main/java/net/typeblog/socks/util/TlsHelloFragmenter.java" \
  "$ROOT/tools/TlsHelloFragmenterSelfTest.java"
java -cp "$TMP" TlsHelloFragmenterSelfTest
