## Privacy policy for Frago

Frago does not collect analytics or send usage data to the Frago developers. The app forwards selected device traffic through its local VPN/TUN path.

When a user imports a configuration containing a DNS-over-HTTPS URL, DNS queries are sent to that configured DNS provider. If the configuration contains `dns.hosts` mappings, matching names are answered locally from those mappings. With a plain DNS upstream, DNS queries are sent to the configured DNS server instead.

The app makes direct TCP connections to destination addresses for the SOCKS5 bridge and uses the configured underlying network for DoH. Users should only import configurations and trust DNS providers they control or trust.
