# Hev resolves its JNI entry points by the fixed package/class name at JNI_OnLoad.
-keep class hev.htproxy.TProxyService { *; }

# Keep any JNI methods exposed by remaining app classes.
-keepclasseswithmembernames,includedescriptorclasses class * {
    native <methods>;
}
