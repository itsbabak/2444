# Frago — standalone Fragment + SOCKS5 for Android (ARM64)

Frago runs without an external proxy core. Its own Java engine exposes a **local SOCKS5 CONNECT listener** on `127.0.0.1:10808`. Android VPN traffic is delivered to that listener by the bundled `tun2socks` component. Frago then opens the destination TCP socket directly and, when enabled, splits the first TLS ClientHello into smaller socket writes.

## Native Frago JSON

Importing JSON is optional. The default values are `packets=tlshello`, `length=10-400`, `interval=1-30`, and DNS `8.8.8.8:53`.

```json
{
  "fragment": {
    "enabled": true,
    "packets": "tlshello",
    "length": "10-400",
    "interval": "1-30"
  },
  "dns": {
    "server": "8.8.8.8",
    "port": 53
  },
  "routing": {
    "skipIranDomains": false,
    "skipPrivateIps": false
  }
}
```

The importer also reads the previous profile layout for migration, but uses only the Fragment parameters and compatible routing/DNS fields; it does not run or bundle that profile's proxy core. DNS upstream must be a plain IP address. HTTPS DoH URLs are not supported by this version and fall back to the default resolver.

## Limitations

- SOCKS5 supports unauthenticated `CONNECT` only; `UDP ASSOCIATE` is not implemented.
- The tunnel and Fragment path are TCP-only. UDP applications, QUIC/HTTP3 and DoH are not supported.
- Fragment applies only to the first TLS ClientHello record. Splitting Java socket writes is best-effort: Android/Linux may coalesce writes, so separate TCP segments are not guaranteed.
- `tun2socks`, `pdnsd`, and the small JNI file-descriptor bridge are retained as VPN/DNS plumbing. They are not proxy cores and are required by this app's TUN architecture.
- Native binaries in this archive are for `arm64-v8a` only.

## Clean release verification

Build with `./gradlew clean verifyReleaseApkNoProxyCore`. The task checks that the APK contains only the three expected ARM64 tunnel/DNS libraries, rejects Xray/V2Ray markers, and fails if the APK exceeds 5 MiB. This catches stale or incorrectly packaged release artifacts.
