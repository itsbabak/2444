package net.typeblog.socks;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.VpnService;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.IBinder;
import android.os.ParcelFileDescriptor;
import android.text.TextUtils;
import android.util.Log;

import net.typeblog.socks.util.FragmentConfig;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

import hev.htproxy.TProxyService;

import static net.typeblog.socks.util.Constants.*;

/** VPN service using Hev TUN-to-SOCKS5 transport and Frago's own Fragment SOCKS5 engine. */
public class SocksVpnService extends VpnService {
    private static final String TAG = "FragoVPN";
    private static final String TUN_IPV4 = "198.18.0.1";
    private static final String ANDROID_DNS_IPV4 = "8.8.8.8";
    private static final String TUN_IPV6 = "fdfe:dcba:9876::1";

    private final IBinder binder = new VpnBinder();
    private ParcelFileDescriptor vpnInterface;
    private volatile boolean running;
    private volatile boolean stopping;
    private volatile boolean hevStarted;
    private volatile FragmentSocks5Engine socksServer;
    private volatile DnsProxy dnsProxy;
    private volatile File hevConfigFile;
    private volatile Network upstreamNetwork;
    private volatile Thread statsMonitor;

    private final class VpnBinder extends IVpnService.Stub {
        @Override public boolean isRunning() { return running && TProxyService.TProxyIsRunning(); }
        @Override public void stop() { stopMe(); }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        if (running || socksServer != null || hevStarted) return START_STICKY;
        stopping = false;

        final String name = intent.getStringExtra(INTENT_NAME);
        final boolean perApp = intent.getBooleanExtra(INTENT_PER_APP, false);
        final String[] appList = intent.getStringArrayExtra(INTENT_APP_LIST);
        final FragmentConfig fragmentConfig;
        try { fragmentConfig = FragmentConfig.parse(intent.getStringExtra(INTENT_FRAGMENT_CONFIG)); }
        catch (Exception e) { Log.e(TAG, "Invalid Fragment JSON", e); stopSelf(); return START_NOT_STICKY; }

        // Capture Android's physical default network before establish() makes the VPN the default.
        upstreamNetwork = findPhysicalDefaultNetwork();
        startForegroundNotification(name);
        if (!configureVpn(name, perApp, appList)) {
            Log.e(TAG, "Could not establish VPN interface or per-app list is empty");
            stopMe();
            return START_NOT_STICKY;
        }

        final int fd = vpnInterface.getFd();
        new Thread(() -> startTunnel(fd, fragmentConfig), "Frago-VPN-Start").start();
        return START_STICKY;
    }

    private void startForegroundNotification(String name) {
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= 26) {
            String channelId = "net.typeblog.socks";
            NotificationChannel channel = new NotificationChannel(channelId,
                    getString(R.string.channel_name), NotificationManager.IMPORTANCE_MIN);
            NotificationManager manager = getSystemService(NotificationManager.class);
            Objects.requireNonNull(manager).createNotificationChannel(channel);
            builder = new Notification.Builder(this, channelId);
        } else {
            builder = new Notification.Builder(this);
        }
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), flags);
        startForeground(1, builder
                .setContentTitle(getString(R.string.notify_title))
                .setContentText(String.format(getString(R.string.notify_msg), name))
                .setPriority(Notification.PRIORITY_MIN)
                .setSmallIcon(R.drawable.ic_vpn)
                .setContentIntent(contentIntent)
                .build());
    }

    private boolean configureVpn(String name, boolean perApp, String[] apps) {
        Builder builder = new Builder();
        builder.setMtu(1500)
                .setSession(TextUtils.isEmpty(name) ? "Frago" : name)
                .addAddress(TUN_IPV4, 24)
                .addAddress(TUN_IPV6, 126)
                // Never use the TUN interface address as the DNS server: it is local to the
                // virtual interface and may be consumed there instead of reaching SOCKS.
                // Hev sends this UDP/53 flow to our SOCKS5 bridge, which answers via configured DoH.
                .addDnsServer(ANDROID_DNS_IPV4)
                .addRoute("0.0.0.0", 0)
                .addRoute("::", 0);

        if (perApp) {
            int added = 0;
            if (apps != null) {
                for (String packageName : apps) {
                    if (TextUtils.isEmpty(packageName) || packageName.trim().equals(getPackageName())) continue;
                    try {
                        builder.addAllowedApplication(packageName.trim());
                        added++;
                    } catch (Exception e) {
                        Log.w(TAG, "Cannot include app " + packageName, e);
                    }
                }
            }
            if (added == 0) return false;
        } else {
            try { builder.addDisallowedApplication(getPackageName()); }
            catch (Exception e) { Log.w(TAG, "Cannot exclude Frago", e); }
        }
        vpnInterface = builder.establish();
        if (vpnInterface != null && upstreamNetwork != null) {
            try { setUnderlyingNetworks(new Network[]{upstreamNetwork}); }
            catch (Exception e) { Log.w(TAG, "Could not pin VPN underlying network", e); }
        }
        Log.i(TAG, "VPN DNS target=" + ANDROID_DNS_IPV4 + ", TUN IPv4=" + TUN_IPV4
                + ", upstream network=" + upstreamNetwork);
        return vpnInterface != null;
    }


    /** Finds the physical default network before the VPN becomes Android's default network. */
    private Network findPhysicalDefaultNetwork() {
        try {
            ConnectivityManager manager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            if (manager == null) return null;
            Network active = manager.getActiveNetwork();
            if (active != null) {
                NetworkCapabilities caps = manager.getNetworkCapabilities(active);
                if (caps != null && !caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return active;
            }
            Network fallback = null;
            for (Network network : manager.getAllNetworks()) {
                NetworkCapabilities caps = manager.getNetworkCapabilities(network);
                if (caps == null || caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue;
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                        || caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                        || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) return network;
                if (fallback == null) fallback = network;
            }
            return fallback;
        } catch (Exception e) {
            Log.w(TAG, "Could not capture physical default network", e);
            return null;
        }
    }

    private void startTunnel(int fd, FragmentConfig fragmentConfig) {
        if (stopping) return;

        DnsProxy resolver = new DnsProxy(this, fragmentConfig, upstreamNetwork);
        dnsProxy = resolver;
        if (!resolver.start() || stopping) {
            Log.e(TAG, "DNS resolver failed to initialize");
            stopMe();
            return;
        }

        FragmentSocks5Engine bridge = new FragmentSocks5Engine(this, fragmentConfig, resolver);
        socksServer = bridge;
        if (!bridge.start() || stopping) {
            Log.e(TAG, "Local SOCKS5 engine failed to start");
            stopMe();
            return;
        }

        try {
            hevConfigFile = writeHevConfig(fragmentConfig.socksPort);
            Log.i(TAG, "Starting Hev TUN-to-SOCKS5 engine from " + hevConfigFile.getAbsolutePath());
            if (!TProxyService.TProxyStartService(hevConfigFile.getAbsolutePath(), fd)) {
                throw new IllegalStateException("Hev JNI refused to start");
            }
            hevStarted = true;

            // JNI starts a native worker thread; wait for configuration parse/start to settle.
            for (int i = 0; i < 30 && !stopping; i++) {
                Thread.sleep(200L);
                if (!TProxyService.TProxyIsRunning()) {
                    throw new IllegalStateException("Hev tunnel exited during startup; check native log");
                }
                if (i >= 4) break;
            }
            if (stopping || !TProxyService.TProxyIsRunning()) {
                throw new IllegalStateException("Hev tunnel is not running");
            }

            running = true;
            long[] stats = TProxyService.TProxyGetStats();
            Log.i(TAG, "Frago active: Hev TUN/SOCKS transport + TCP TLS Fragment; initial stats="
                    + java.util.Arrays.toString(stats));
            startStatsMonitor();
        } catch (Throwable e) {
            Log.e(TAG, "Could not start Hev TUN-to-SOCKS5 transport", e);
            stopMe();
        }
    }


    /** Periodically reports native TUN counters so a live VPN service is not confused with internet reachability. */
    private void startStatsMonitor() {
        Thread monitor = new Thread(() -> {
            while (running && !stopping && TProxyService.TProxyIsRunning()) {
                try { Thread.sleep(15000L); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
                if (!running || stopping) break;
                try {
                    long[] counters = TProxyService.TProxyGetStats();
                    if (counters != null && counters.length >= 4) {
                        Log.i(TAG, "Hev TUN stats: txPackets=" + counters[0] + ", txBytes=" + counters[1]
                                + ", rxPackets=" + counters[2] + ", rxBytes=" + counters[3]);
                    } else {
                        Log.w(TAG, "Hev returned no TUN counters");
                    }
                } catch (Throwable e) {
                    Log.w(TAG, "Could not read Hev TUN counters", e);
                    break;
                }
            }
        }, "Frago-TUN-Stats");
        monitor.setDaemon(true);
        statsMonitor = monitor;
        monitor.start();
    }

    private File writeHevConfig(int socksPort) throws Exception {
        // Hev's SOCKS5 UDP mode uses RFC 1928 UDP ASSOCIATE against Frago's local SOCKS5 server.
        String yaml = "tunnel:\n"
                + "  name: frago\n"
                + "  mtu: 1500\n"
                + "  ipv4: " + TUN_IPV4 + "\n"
                + "  ipv6: '" + TUN_IPV6 + "'\n"
                + "  icmp: 'off'\n"
                + "socks5:\n"
                + "  address: 127.0.0.1\n"
                + "  port: " + socksPort + "\n"
                + "  udp: 'udp'\n"
                + "misc:\n"
                + "  connect-timeout: 12000\n"
                + "  tcp-read-write-timeout: 300000\n"
                + "  udp-read-write-timeout: 60000\n"
                + "  tcp-buffer-size: 32768\n"
                + "  udp-recv-buffer-size: 262144\n"
                + "  udp-copy-buffer-nums: 10\n"
                + "  max-session-count: 1200\n"
                + "  log-level: info\n";
        File file = new File(getFilesDir(), "hev-socks5-tunnel.yaml");
        try (FileOutputStream out = new FileOutputStream(file, false)) {
            out.write(yaml.getBytes(StandardCharsets.UTF_8));
            out.flush();
            out.getFD().sync();
        }
        return file;
    }

    private void stopMe() {
        stopping = true;
        running = false;
        Thread monitor = statsMonitor;
        statsMonitor = null;
        if (monitor != null) monitor.interrupt();
        stopForeground(true);

        if (hevStarted) {
            try {
                Log.i(TAG, "Stopping Hev TUN-to-SOCKS5 engine");
                TProxyService.TProxyStopService();
            } catch (Throwable e) {
                Log.w(TAG, "Could not stop Hev native engine", e);
            }
            hevStarted = false;
        }

        FragmentSocks5Engine bridge = socksServer;
        socksServer = null;
        if (bridge != null) bridge.stop();
        DnsProxy resolver = dnsProxy;
        dnsProxy = null;
        if (resolver != null) resolver.stop();

        if (vpnInterface != null) {
            try { vpnInterface.close(); }
            catch (Exception e) { Log.w(TAG, "Could not close VPN interface", e); }
            vpnInterface = null;
        }
        stopSelf();
    }

    @Override public void onRevoke() {
        super.onRevoke();
        stopMe();
    }

    @Override public IBinder onBind(Intent intent) { return binder; }

    @Override public void onDestroy() {
        stopMe();
        super.onDestroy();
    }
}
