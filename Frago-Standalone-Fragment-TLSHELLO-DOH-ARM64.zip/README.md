# Frago — standalone TLS Fragment + SOCKS5 (ARM64)

Frago is an Android VPN app with a small in-app SOCKS5 CONNECT bridge and a Java TLS ClientHello fragmenter. It does not bundle Xray/V2Ray or another proxy core.

## Supported imported Xray-style JSON subset

The importer reads the configuration form used by Frago's `freedom` outbound: `outbounds[].tag=fragment-out`, `protocol=freedom`, `settings.fragment.packets=tlshello`, `length`, and `interval`. For `tlshello`, Frago splits the ClientHello handshake payload into multiple TLS Handshake records and rewrites each TLS record length, following the behavior of Xray's `freedom.FragmentWriter`; it does not merely issue several writes of the same TLS record. Fragment is applied to TCP TLS ClientHello connections.

The DNS subset supports `dns.servers` with an HTTPS DoH URL, `queryStrategy=UseIPv4`, and `dns.hosts` exact/`regexp:` IPv4 mappings. Non-DoH plain IPv4 DNS upstreams are also supported. Direct routing rules for `.ir` domains and private IP ranges are recognized.

Example matching the supplied config shape:

```json
{
  "dns": {
    "servers": ["https://kid.openbld.net/dns-query"],
    "queryStrategy": "UseIPv4",
    "hosts": {"regexp:(google)": ["65.109.184.128", "91.107.241.144"]}
  },
  "outbounds": [{
    "tag": "fragment-out",
    "protocol": "freedom",
    "settings": {"domainStrategy": "UseIPv4", "fragment": {
      "packets": "tlshello", "length": "10-400", "interval": "1-30"
    }}
  }]
}
```

## Runtime path

Android VPN/TUN -> tun2socks -> local SOCKS5 `127.0.0.1:10808` -> direct protected TCP socket -> TLS ClientHello fragmentation. DNS requests are sent to the in-app DNS forwarder on UDP/8091, which applies hosts mappings and forwards via DoH/plain DNS over the underlying network.

## Limitations

- The current SOCKS5 bridge implements CONNECT, not UDP ASSOCIATE. General UDP and QUIC/HTTP3 are not tunneled by this build; apps/browsers need to fall back to TCP.
- Only `packets=tlshello` is supported; Xray proxy protocols (VLESS, VMess, REALITY, etc.) are not loaded.
- `dns.hosts` currently accepts IPv4 arrays; full Xray routing/geosite/geoip databases and all DNS transports are not implemented.
- TCP segmentation on the wire is controlled by the operating system; Frago reproduces Xray's TLS-record fragmentation behavior, but cannot guarantee how a remote network interface emits each segment.
