import java.io.*;
import java.util.*;
import net.typeblog.socks.util.TlsHelloFragmenter;

public class TlsHelloFragmenterSelfTest {
  static byte[] u16(int v) { return new byte[]{(byte)(v>>>8),(byte)v}; }
  static byte[] u24(int v) { return new byte[]{(byte)(v>>>16),(byte)(v>>>8),(byte)v}; }
  static byte[] concat(byte[]... a) throws Exception { ByteArrayOutputStream o=new ByteArrayOutputStream(); for(byte[] b:a)o.write(b);return o.toByteArray(); }
  static byte[] clientHello(String sni) throws Exception {
    byte[] host=sni.getBytes("US-ASCII");
    byte[] snEntry=concat(new byte[]{0},u16(host.length),host);
    byte[] snList=concat(u16(snEntry.length),snEntry);
    byte[] sniExt=concat(u16(0),u16(snList.length),snList);
    byte[] cipher=concat(u16(0x1301),u16(0x1302));
    byte[] body=concat(new byte[]{3,3},new byte[32],new byte[]{0},u16(cipher.length),cipher,new byte[]{1,0},u16(sniExt.length),sniExt);
    byte[] hs=concat(new byte[]{1},u24(body.length),body);
    byte[] record=concat(new byte[]{22,3,1},u16(hs.length),hs);
    return record;
  }
  public static void main(String[] args) throws Exception {
    byte[] in=clientHello("www.google.com");
    if (!"www.google.com".equals(TlsHelloFragmenter.extractSni(in))) throw new AssertionError("SNI parse failed");
    ByteArrayOutputStream out=new ByteArrayOutputStream();
    int chunks=TlsHelloFragmenter.writeFragments(out,in,20,40,0,0);
    byte[] wire=out.toByteArray();
    int p=0, parsed=0; ByteArrayOutputStream payload=new ByteArrayOutputStream();
    while(p<wire.length) {
      if((wire[p]&255)!=22) throw new AssertionError("record type changed");
      int len=((wire[p+3]&255)<<8)|(wire[p+4]&255);
      if(len<1 || p+5+len>wire.length) throw new AssertionError("bad TLS record length");
      payload.write(wire,p+5,len); p+=5+len; parsed++;
    }
    if(chunks!=parsed || parsed<2) throw new AssertionError("expected multiple records");
    if(!Arrays.equals(in,concat(new byte[]{22,3,1},u16(payload.size()),payload.toByteArray()))) throw new AssertionError("hello payload changed");
    System.out.println("PASS: extracted SNI, emitted " + parsed + " independent TLS records, all lengths valid, reassembled payload identical; source bytes="+in.length+", output bytes="+wire.length);
  }
}
