# تغییرات نسخه Hev AAR fix

- اصلاح منبع Hev: به جای standalone Android PIE executable از AAR رسمی شامل JNI shared library استفاده می‌شود.
- استخراج فقط `jni/arm64-v8a/libhev-socks5-tunnel.so` از AAR.
- کنترل ELF برای رد executableهای دارای `PT_INTERP`.
- کنترل وجود `JNI_OnLoad` و قرارداد `hev/htproxy/TProxyService`.
- حفظ ARM64-only و حذف کامل Xray/V2Ray.
- حفظ مسیر TUN -> Hev JNI -> SOCKS5 اختصاصی Frago -> TLS ClientHello Fragment.
