#!/usr/bin/env python3
"""Regression guard for the supplied Xray-style JSON subset imported by Frago."""
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
config = json.loads((root / "frago-example.json").read_text(encoding="utf-8"))

inbounds = config.get("inbounds", [])
socks = next((item for item in inbounds if item.get("tag") == "socks-in"), None)
assert socks is not None, "missing socks-in inbound"
assert socks.get("protocol") == "socks"
assert socks.get("listen") == "127.0.0.1" and socks.get("port") == 10808
assert socks.get("settings", {}).get("udp") is True

outbounds = config.get("outbounds", [])
fragment = next((item for item in outbounds if item.get("tag") == "fragment-out"), None)
assert fragment is not None, "missing fragment-out outbound"
assert fragment.get("protocol") == "freedom"
fragment_settings = fragment.get("settings", {}).get("fragment", {})
assert fragment_settings.get("packets") == "tlshello"
assert fragment_settings.get("length") == "10-400"
assert fragment_settings.get("interval") == "1-30"

servers = config.get("dns", {}).get("servers", [])
assert servers and servers[0] == "https://kid.openbld.net/dns-query"
assert config["dns"].get("queryStrategy") == "UseIPv4"
assert config["dns"].get("hosts", {}).get("regexp:(google)") == [
    "65.109.184.128", "91.107.241.144"
]

rules = config.get("routing", {}).get("rules", [])
assert any("regexp:.*\\.ir$" in rule.get("domain", []) and rule.get("outboundTag") == "direct" for rule in rules)
assert any(rule.get("network") == "tcp" and rule.get("outboundTag") == "fragment-out" for rule in rules)
assert any(rule.get("network") == "udp" and rule.get("outboundTag") == "direct" for rule in rules)

source = (root / "app/src/main/java/net/typeblog/socks/SocksVpnService.java").read_text(encoding="utf-8")
assert '.addDnsServer(ANDROID_DNS_IPV4)' in source
assert 'ANDROID_DNS_IPV4 = "8.8.8.8"' in source
print("PASS: supplied JSON subset and DNS-to-SOCKS routing assumptions verified")
