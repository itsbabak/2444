# راهنمای عیب‌یابی Frago Hev + Fragment

برای ثبت لاگ در گوشی:

```bash
adb logcat -c
adb logcat -s FragoVPN FragoDNS FragoSOCKS5
```

نشانه‌های مورد انتظار پس از اتصال:

- `SOCKS5 ready on 127.0.0.1:10808`
- `Starting Hev TUN-to-SOCKS5 engine`
- `Frago active: Hev TUN/SOCKS transport + TCP TLS Fragment`
- هر ۱۵ ثانیه شمارنده‌های `Hev TUN stats` شامل tx/rx packets و bytes
- برای TLS: `TLS ClientHello fragmented` همراه SNI و تعداد رکوردها
- برای DNS موفق: `Resolved <domain> ... via DoH` یا `via hosts`

تفسیر اولیه:

- اگر txPackets و txBytes صفر بمانند، هنوز ترافیک برنامه‌ها وارد TUN نشده است؛ حالت انتخاب برنامه‌ها/Route را بررسی کنید.
- اگر tx زیاد شود اما rx صفر بماند، مسیر SOCKS یا اتصال خروجی/پاسخ سرور را بررسی کنید.
- اگر DNS خطای `DNS query failed` بدهد، مسیر DoH و شبکه فیزیکی ثبت‌شده را بررسی کنید.
- اگر اتصال برقرار است اما برای سایت HTTPS هیچ `TLS ClientHello fragmented` ثبت نمی‌شود، آن برنامه از QUIC/UDP استفاده کرده، TLS را از مسیر دیگری فرستاده، یا مقصد طبق قانون direct شده است.

این لاگ‌ها برای تشخیص‌اند و هیچ رمز عبور یا محتوای کامل ترافیک را چاپ نمی‌کنند.
