#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/src/android/content" "$TMP/src/android/net" "$TMP/src/android/util" "$TMP/src/org/json" "$TMP/classes"

cat > "$TMP/src/android/content/Context.java" <<'JAVA'
package android.content;
public class Context { public static final String CONNECTIVITY_SERVICE="connectivity"; public Object getSystemService(String name){ return null; } }
JAVA
cat > "$TMP/src/android/net/VpnService.java" <<'JAVA'
package android.net;
import android.content.Context;
import java.net.DatagramSocket;
import java.net.Socket;
public class VpnService extends Context { public boolean protect(DatagramSocket socket){ return true; } public boolean protect(Socket socket){ return true; } }
JAVA
cat > "$TMP/src/android/net/ConnectivityManager.java" <<'JAVA'
package android.net;
public class ConnectivityManager { public Network[] getAllNetworks(){ return new Network[0]; } public NetworkCapabilities getNetworkCapabilities(Network n){ return null; } }
JAVA
cat > "$TMP/src/android/net/Network.java" <<'JAVA'
package android.net;
import java.net.URL;
import java.net.URLConnection;
public class Network { public URLConnection openConnection(URL url) throws java.io.IOException { return url.openConnection(); } }
JAVA
cat > "$TMP/src/android/net/NetworkCapabilities.java" <<'JAVA'
package android.net;
public class NetworkCapabilities { public static final int TRANSPORT_VPN=4, TRANSPORT_WIFI=1, TRANSPORT_CELLULAR=0, TRANSPORT_ETHERNET=3; public boolean hasTransport(int t){ return false; } }
JAVA
cat > "$TMP/src/android/util/Log.java" <<'JAVA'
package android.util;
public class Log { public static int w(String t,String m,Throwable e){ System.err.println("W "+t+" "+m); if(e!=null)e.printStackTrace(); return 0; } public static int e(String t,String m,Throwable e){ System.err.println("E "+t+" "+m); if(e!=null)e.printStackTrace(); return 0; } public static int i(String t,String m){ System.err.println("I "+t+" "+m); return 0; } public static int d(String t,String m){ System.err.println("D "+t+" "+m); return 0; } }
JAVA
cat > "$TMP/src/org/json/JSONObject.java" <<'JAVA'
package org.json;
import java.util.Collections; import java.util.Iterator;
public class JSONObject { public JSONObject(){} public JSONObject(String s){} public JSONObject optJSONObject(String s){return null;} public JSONArray optJSONArray(String s){return null;} public boolean optBoolean(String s,boolean d){return d;} public String optString(String s,String d){return d;} public String optString(String s){return "";} public int optInt(String s,int d){return d;} public Iterator<String> keys(){return Collections.<String>emptyList().iterator();} }
JAVA
cat > "$TMP/src/org/json/JSONArray.java" <<'JAVA'
package org.json;
public class JSONArray { public int length(){return 0;} public JSONObject optJSONObject(int i){return null;} public String optString(int i,String d){return d;} }
JAVA

javac -source 8 -target 8 -d "$TMP/classes" \
  $(find "$TMP/src" -name '*.java') \
  "$ROOT/app/src/main/java/net/typeblog/socks/util/FragmentConfig.java" \
  "$ROOT/app/src/main/java/net/typeblog/socks/util/TlsHelloFragmenter.java" \
  "$ROOT/app/src/main/java/net/typeblog/socks/DnsProxy.java" \
  "$ROOT/app/src/main/java/net/typeblog/socks/FragmentSocks5Engine.java" \
  "$ROOT/tools/Socks5TunnelSelfTest.java"
java -cp "$TMP/classes" net.typeblog.socks.Socks5TunnelSelfTest
