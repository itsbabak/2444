# Frago — lightweight ARM64 VPN with TLS ClientHello Fragment

Frago uses two small components instead of a general-purpose proxy core:

1. **HevSocks5Tunnel 2.20.0** handles Android TUN-to-SOCKS5 transport. The build downloads the official Android AAR and extracts its real ARM64 JNI shared library. Do not use the separately published `hev-socks5-tunnel-android-arm64-v8a` standalone executable as a `.so`.
2. **Frago's Java SOCKS5 engine** handles local SOCKS5 CONNECT and UDP ASSOCIATE. TCP TLS ClientHello is fragmented into separate TLS Handshake records according to the imported `length` and `interval` ranges. DNS queries and hostname resolution use the configured DoH/plain DNS path and `hosts` overrides.

No Xray/V2Ray core is bundled or executed.

## Hev integration detail

The upstream Hev Android AAR contains `jni/arm64-v8a/libhev-socks5-tunnel.so` and uses the default JNI contract `hev.htproxy.TProxyService`. Frago keeps a matching Java bridge class. The workflow extracts only the ARM64 `.so` from the AAR and verifies that it is a shared object (not a PIE executable), has no `PT_INTERP`, exports `JNI_OnLoad`, and references the expected JNI class before Gradle packages it.

## Import compatibility

The importer supports the subset used by the supplied JSON:

- `inbounds[].protocol=socks`, loopback port 10808 and UDP enabled (local port remains 10808)
- `outbounds[].tag=fragment-out`, `protocol=freedom`, `settings.fragment.packets=tlshello`
- Fragment `length` and `interval` ranges
- `dns.servers` with an HTTPS DoH URL or plain IPv4 DNS server
- `dns.queryStrategy=UseIPv4`
- `dns.hosts` exact and `regexp:` IPv4 overrides
- direct/no-fragment handling for `.ir` SNI names and private/loopback destination addresses
- TCP connections use Fragment; UDP connections are forwarded directly through SOCKS5 UDP ASSOCIATE

This is not a full Xray JSON interpreter. It does not support VLESS, VMess, REALITY, geosite/geoip databases, arbitrary routing expressions, or Xray's full sniffing implementation. UDP is transported directly; TLS ClientHello Fragment applies only to TCP/TLS.

## Data path

```text
Android applications
  -> Android VpnService TUN
  -> HevSocks5Tunnel JNI shared library (TUN-to-SOCKS5 bridge)
  -> Frago local SOCKS5 127.0.0.1:10808
       TCP CONNECT -> protected TCP socket -> optional TLS ClientHello record fragmentation
       UDP ASSOCIATE -> protected UDP socket -> direct UDP relay
       UDP/53 -> Frago DNS resolver -> DoH / configured DNS + hosts overrides
```

The app protects its own outbound TCP/UDP sockets from the VPN to avoid a routing loop. The Android DNS server is set to 8.8.8.8 so DNS packets enter the TUN and reach the SOCKS5 bridge; the bridge returns answers using the imported DoH URL. DoH is bound to the physical network captured before the VPN is established where Android exposes one.

## Build from GitHub Actions

The workflow can take the ZIP as the only source file in the repository. It extracts the archive, downloads the official Hev Android AAR, extracts the ARM64 JNI shared object (not the similarly named standalone executable), checks its ELF/JNI contract, compiles the Release APK and checks that the APK contains only `libhev-socks5-tunnel.so` as its native library and no Xray/V2Ray/legacy BadVPN payload.

## Limitations and test status

- The Java SOCKS5 implementation supports TCP CONNECT and UDP ASSOCIATE. SOCKS UDP fragmentation (`FRAG` other than zero) is not implemented; Hev sends normal unfragmented SOCKS5 UDP datagrams.
- DNS host overrides currently return IPv4 answers; `UseIPv4` intentionally returns no AAAA records.
- The `.ir` direct rule is applied from TLS SNI when the TUN/SOCKS path provides only the destination IP. This does not recreate all Xray sniffing behaviors.
- Local tests cover Java compilation of changed classes, SOCKS5 TCP CONNECT loopback, TLS ClientHello fragmentation through the live SOCKS5 TCP path, and SOCKS5 UDP ASSOCIATE loopback. They do not execute Android TUN or a physical device. GitHub Actions performs the official AAR download, JNI/ELF checks and Android build.

## Third-party notices

HevSocks5Tunnel is licensed under MIT; see `licenses/HEV-SOCKS5-TUNNEL-LICENSE.txt`. Upstream source and releases: https://github.com/heiher/hev-socks5-tunnel/releases/tag/2.20.0.
