# Frago — lightweight ARM64 VPN with TLS ClientHello Fragment

Frago uses two small components instead of a general-purpose proxy core:

1. **HevSocks5Tunnel 2.20.0** handles Android TUN-to-SOCKS5 transport. Its upstream ARM64 Android shared library is 247 KB and supports TCP, UDP, IPv4 and IPv6. The build workflow downloads the official release asset and verifies its SHA-256 before packaging it.
2. **Frago's Java SOCKS5 engine** handles local SOCKS5 CONNECT and UDP ASSOCIATE. TCP TLS ClientHello is fragmented into separate TLS Handshake records according to the imported `length` and `interval` ranges. DNS queries and hostname resolution use the configured DoH/plain DNS path and `hosts` overrides.

No Xray/V2Ray core is bundled or executed.

## Import compatibility

The importer supports the subset used by the supplied JSON:

- `inbounds[].protocol=socks`, loopback port 10808 and UDP enabled (local port remains 10808)
- `outbounds[].tag=fragment-out`, `protocol=freedom`, `settings.fragment.packets=tlshello`
- Fragment `length` and `interval` ranges
- `dns.servers` with an HTTPS DoH URL or plain IPv4 DNS server
- `dns.queryStrategy=UseIPv4`
- `dns.hosts` exact and `regexp:` IPv4 overrides
- direct/no-fragment handling for `.ir` SNI names and private/loopback destination addresses
- TCP connections use Fragment; UDP connections are forwarded directly through SOCKS5 UDP ASSOCIATE

This is not a full Xray JSON interpreter. It does not support VLESS, VMess, REALITY, geosite/geoip databases, arbitrary routing expressions, or Xray's full sniffing implementation. UDP is transported directly; TLS ClientHello Fragment applies only to TCP/TLS.

## Data path

```text
Android applications
  -> Android VpnService TUN (DNS target 8.8.8.8:53 is intercepted by Frago)
  -> HevSocks5Tunnel (small native TUN-to-SOCKS5 bridge)
  -> Frago local SOCKS5 127.0.0.1:10808
       TCP CONNECT -> protected TCP socket -> optional TLS ClientHello record fragmentation
       UDP ASSOCIATE -> protected UDP socket -> direct UDP relay
       UDP/53 -> Frago DNS resolver -> DoH / configured DNS + hosts overrides
```

The app protects its own outbound TCP/UDP sockets from the VPN to avoid a routing loop. The Android DNS server is set to 8.8.8.8 so DNS packets enter the TUN and reach the SOCKS5 bridge; the bridge returns answers using the imported DoH URL. DoH is bound to the physical network captured before the VPN is established where Android exposes one.

## Build from GitHub Actions

The workflow can take the ZIP as the only source file in the repository. It extracts the archive, downloads the official Hev ARM64 shared library, verifies its published SHA-256, compiles the Release APK and checks that the APK contains only `libhev-socks5-tunnel.so` as its native library and no Xray/V2Ray/legacy BadVPN payload.

## Limitations and test status

- The Java SOCKS5 implementation supports TCP CONNECT and UDP ASSOCIATE. SOCKS UDP fragmentation (`FRAG` other than zero) is not implemented; Hev sends normal unfragmented SOCKS5 UDP datagrams.
- DNS host overrides currently return IPv4 answers; `UseIPv4` intentionally returns no AAAA records.
- The `.ir` direct rule is applied from TLS SNI when the TUN/SOCKS path provides only the destination IP. This does not recreate all Xray sniffing behaviors.
- Local checks include Java compilation of the changed classes, SOCKS5 TCP CONNECT loopback, TLS ClientHello fragmentation through the live SOCKS5 TCP path, and SOCKS5 UDP ASSOCIATE loopback. These tests use JVM loopback sockets; they do not execute Android TUN or the native Hev library. The official native library cannot be downloaded in this offline build container, and no Android device test or complete APK build has been performed here. GitHub Actions performs the pinned native download and Android build.

## Third-party notices

HevSocks5Tunnel is licensed under MIT; see `licenses/HEV-SOCKS5-TUNNEL-LICENSE.txt`. The pinned upstream release asset is documented at https://github.com/heiher/hev-socks5-tunnel/releases/tag/2.20.0.
