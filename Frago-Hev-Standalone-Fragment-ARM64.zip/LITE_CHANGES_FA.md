# تغییرات نسخه مستقل Frago (Hev + Fragment)

- حذف کامل Xray/V2Ray و کتابخانه‌های قدیمی `libtun2socks.so` و `libsystem.so`.
- جایگزینی انتقال TUN با HevSocks5Tunnel 2.20.0؛ کتابخانه رسمی ARM64 حدود 247KB است و در GitHub Actions با SHA-256 بررسی می‌شود.
- موتور SOCKS5 داخلی Frago از TCP CONNECT و UDP ASSOCIATE پشتیبانی می‌کند.
- Fragment اختصاصی در مسیر TCP خروجی اجرا می‌شود و TLS ClientHello را به چند TLS Handshake Record با طول‌های مستقل تقسیم می‌کند.
- DNS سیستم به 8.8.8.8 هدایت می‌شود تا بسته‌های UDP/53 وارد TUN شوند؛ پل SOCKS5 آن‌ها را از DoH واردشده پاسخ می‌دهد.
- DoH به شبکه فیزیکی‌ای متصل می‌شود که قبل از فعال‌شدن VPN ثبت شده است.
- پشتیبانی از `UseIPv4`، hosts regex و direct برای دامنه‌های `.ir` و IPهای خصوصی طبق JSON نمونه.
- Build فقط ARM64 است و کنترل محتویات Native قبل از انتشار انجام می‌شود.

تست محلی شامل کامپایل ایستای کلاس‌های تغییرکرده، TCP CONNECT loopback، Fragment در مسیر زنده SOCKS5 TCP، UDP ASSOCIATE loopback و کنترل ساختار JSON است. این تست‌ها JVM loopback هستند و Android TUN یا native Hev را اجرا نمی‌کنند؛ تست نهایی APK و دستگاه واقعی هنوز لازم است.
