package net.typeblog.socks.util;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/** Minimal configuration model for Frago's SOCKS5/TLS-Fragment and DNS path. */
public final class FragmentConfig {
    public static final int LOCAL_SOCKS_PORT = 10808;
    public static final int DNS_GATEWAY_PORT = 8091;
    private static final String DEFAULT_DNS = "8.8.8.8";

    public static final class HostRule {
        public final String expression;
        public final boolean regex;
        public final List<String> addresses;
        private final Pattern pattern;

        HostRule(String expression, boolean regex, List<String> addresses) {
            this.expression = expression;
            this.regex = regex;
            this.addresses = addresses;
            this.pattern = regex ? Pattern.compile(expression, Pattern.CASE_INSENSITIVE) : null;
        }

        public boolean matches(String host) {
            if (host == null) return false;
            String value = host.toLowerCase(Locale.ROOT);
            return regex ? pattern.matcher(value).find() : value.equals(expression.toLowerCase(Locale.ROOT));
        }
    }

    public final int socksPort;
    public final int minLength;
    public final int maxLength;
    public final int minInterval;
    public final int maxInterval;
    public final int dnsPort;
    public final String dnsServer;
    public final String dohUrl;
    public final boolean useIpv4Only;
    public final boolean fragmentTcp;
    public final boolean directIranDomains;
    public final boolean directPrivateIps;
    public final List<HostRule> hostRules;

    private FragmentConfig(int min, int max, int minDelay, int maxDelay,
                           int resolverPort, String resolver, String doh,
                           boolean ipv4, boolean enabled, boolean iranDirect,
                           boolean privateDirect, List<HostRule> hosts) {
        socksPort = LOCAL_SOCKS_PORT;
        minLength = min;
        maxLength = max;
        minInterval = minDelay;
        maxInterval = maxDelay;
        dnsPort = resolverPort;
        dnsServer = resolver;
        dohUrl = doh;
        useIpv4Only = ipv4;
        fragmentTcp = enabled;
        directIranDomains = iranDirect;
        directPrivateIps = privateDirect;
        hostRules = hosts;
    }

    /**
     * Reads Frago's small schema and the supplied Xray-style JSON subset:
     * freedom.settings.fragment, dns.servers/hosts/queryStrategy and direct routing rules.
     * It does not load or execute Xray.
     */
    public static FragmentConfig parse(String raw) throws Exception {
        JSONObject root = (raw == null || raw.trim().isEmpty())
                ? new JSONObject() : new JSONObject(raw);

        JSONObject fragment = root.optJSONObject("fragment");
        if (fragment == null) fragment = findLegacyFragment(root);

        boolean enabled = fragment == null || fragment.optBoolean("enabled", true);
        String packets = fragment == null
                ? "tlshello" : fragment.optString("packets", "tlshello").trim().toLowerCase(Locale.ROOT);
        if (enabled && !"tlshello".equals(packets)) {
            throw new IllegalArgumentException("Frago پشتیبانی می‌کند از packets=tlshello");
        }

        int[] length = parseRange(fragment == null ? "10-400" : fragment.optString("length", "10-400"), 10, 400);
        int[] interval = parseRange(fragment == null ? "1-30" : fragment.optString("interval", "1-30"), 1, 30);
        int min = clamp(length[0], 1, 4096);
        int max = clamp(length[1], min, 8192);
        int minDelay = clamp(interval[0], 0, 1000);
        int maxDelay = clamp(interval[1], minDelay, 2000);

        String dnsServer = DEFAULT_DNS;
        String dohUrl = "";
        int dnsPort = 53;
        boolean useIpv4 = false;
        List<HostRule> hostRules = new ArrayList<>();
        JSONObject dns = root.optJSONObject("dns");
        if (dns != null) {
            String strategy = dns.optString("queryStrategy", "UseIPv4");
            useIpv4 = "UseIPv4".equalsIgnoreCase(strategy);

            dnsPort = clamp(dns.optInt("port", 53), 1, 65535);
            String candidate = dns.optString("server", "").trim();
            JSONArray servers = dns.optJSONArray("servers");
            if (servers != null && servers.length() > 0) {
                // Prefer the first configured server, as in the supplied Xray JSON.
                candidate = servers.optString(0, candidate).trim();
            }
            if (candidate.regionMatches(true, 0, "https://", 0, 8)) {
                dohUrl = candidate;
            } else if (isPlainDnsServer(candidate)) {
                dnsServer = candidate;
            }

            JSONObject hosts = dns.optJSONObject("hosts");
            if (hosts != null) {
                Iterator<String> keys = hosts.keys();
                while (keys.hasNext()) {
                    String key = keys.next();
                    JSONArray values = hosts.optJSONArray(key);
                    if (values == null) continue;
                    String expression = key;
                    boolean regex = key.regionMatches(true, 0, "regexp:", 0, 7);
                    if (regex) expression = key.substring(7);
                    List<String> addresses = new ArrayList<>();
                    for (int i = 0; i < values.length(); i++) {
                        String ip = values.optString(i, "").trim();
                        if (isIPv4(ip)) addresses.add(ip);
                    }
                    if (!addresses.isEmpty()) {
                        try { hostRules.add(new HostRule(expression, regex, addresses)); }
                        catch (Exception e) { throw new IllegalArgumentException("الگوی hosts نامعتبر است: " + key, e); }
                    }
                }
            }
        }

        boolean skipIran = false;
        boolean skipPrivate = false;
        JSONObject routing = root.optJSONObject("routing");
        if (routing != null) {
            skipIran = routing.optBoolean("skipIranDomains", false);
            skipPrivate = routing.optBoolean("skipPrivateIps", false);
            JSONArray rules = routing.optJSONArray("rules");
            if (rules != null) {
                for (int i = 0; i < rules.length(); i++) {
                    JSONObject rule = rules.optJSONObject(i);
                    if (rule == null || !"direct".equals(rule.optString("outboundTag"))) continue;
                    JSONArray domains = rule.optJSONArray("domain");
                    if (domains != null) {
                        for (int j = 0; j < domains.length(); j++) {
                            String value = domains.optString(j, "").toLowerCase(Locale.ROOT);
                            if (value.contains("\\.ir") || value.endsWith(".ir")) skipIran = true;
                        }
                    }
                    JSONArray ips = rule.optJSONArray("ip");
                    if (ips != null && ips.length() > 0) skipPrivate = true;
                }
            }
        }

        return new FragmentConfig(min, max, minDelay, maxDelay, dnsPort, dnsServer,
                dohUrl, useIpv4, enabled, skipIran, skipPrivate, hostRules);
    }

    private static JSONObject findLegacyFragment(JSONObject root) {
        JSONArray outbounds = root.optJSONArray("outbounds");
        if (outbounds == null) return null;
        for (int i = 0; i < outbounds.length(); i++) {
            JSONObject outbound = outbounds.optJSONObject(i);
            if (outbound == null || !"fragment-out".equals(outbound.optString("tag"))) continue;
            if (!"freedom".equalsIgnoreCase(outbound.optString("protocol", "freedom"))) {
                throw new IllegalArgumentException("fragment-out باید از نوع freedom باشد");
            }
            JSONObject settings = outbound.optJSONObject("settings");
            return settings == null ? null : settings.optJSONObject("fragment");
        }
        return null;
    }

    public boolean shouldFragmentHost(String host) {
        if (!fragmentTcp) return false;
        if (host == null) return true;
        String normalized = host.trim().toLowerCase(Locale.ROOT);
        if (directIranDomains && (normalized.equals("ir") || normalized.endsWith(".ir"))) return false;
        return !directPrivateIps || !isPrivateOrLoopback(normalized);
    }

    public boolean shouldFragmentSni(String sni) {
        if (!fragmentTcp) return false;
        if (sni == null || sni.isEmpty()) return true;
        String normalized = sni.trim().toLowerCase(Locale.ROOT);
        if (directIranDomains && (normalized.equals("ir") || normalized.endsWith(".ir"))) return false;
        return true;
    }

    public List<String> findHostOverride(String host) {
        for (HostRule rule : hostRules) if (rule.matches(host)) return rule.addresses;
        return null;
    }

    private static boolean isPlainDnsServer(String value) {
        return isIPv4(value) || (value != null && value.indexOf(':') >= 0
                && value.matches("[0-9a-fA-F:%.]+"));
    }

    private static boolean isIPv4(String value) {
        if (value == null || !value.matches("[0-9]{1,3}(\\.[0-9]{1,3}){3}")) return false;
        String[] octets = value.split("\\.");
        for (String octet : octets) {
            try { int number = Integer.parseInt(octet); if (number < 0 || number > 255) return false; }
            catch (NumberFormatException e) { return false; }
        }
        return true;
    }

    private static boolean isPrivateOrLoopback(String host) {
        try {
            if (!(isIPv4(host) || host.indexOf(':') >= 0)) return false;
            byte[] address = InetAddress.getByName(host).getAddress();
            if (address.length == 4) {
                int first = address[0] & 255;
                int second = address[1] & 255;
                return first == 10 || first == 127
                        || (first == 172 && second >= 16 && second <= 31)
                        || (first == 192 && second == 168);
            }
            return (address[0] & 0xfe) == 0xfc || InetAddress.getByAddress(address).isLoopbackAddress();
        } catch (Exception ignored) { return false; }
    }

    private static int[] parseRange(String value, int fallbackMin, int fallbackMax) {
        try {
            String[] parts = value.trim().split("-");
            if (parts.length == 1) {
                int number = Integer.parseInt(parts[0].trim());
                return new int[]{number, number};
            }
            if (parts.length == 2) {
                int first = Integer.parseInt(parts[0].trim());
                int second = Integer.parseInt(parts[1].trim());
                return new int[]{Math.min(first, second), Math.max(first, second)};
            }
        } catch (Exception ignored) { }
        return new int[]{fallbackMin, fallbackMax};
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(value, max));
    }
}
