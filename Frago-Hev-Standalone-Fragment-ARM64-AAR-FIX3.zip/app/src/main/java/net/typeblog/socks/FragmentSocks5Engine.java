package net.typeblog.socks;

import android.net.VpnService;
import android.util.Log;

import net.typeblog.socks.util.FragmentConfig;
import net.typeblog.socks.util.TlsHelloFragmenter;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.ConnectException;
import java.net.NoRouteToHostException;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

/** Local SOCKS5 server with TCP ClientHello fragmentation and RFC 1928 UDP ASSOCIATE. */
final class FragmentSocks5Engine {
    private static final String TAG = "FragoSOCKS5";
    private static final int CONNECT_TIMEOUT_MS = 12000;
    private static final int HANDSHAKE_TIMEOUT_MS = 15000;
    private static final int UDP_PACKET_MAX = 65507;

    private final VpnService vpn;
    private final FragmentConfig config;
    private final DnsProxy dns;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private final ExecutorService workers = Executors.newCachedThreadPool();
    private final Set<Socket> activeTcpSockets = ConcurrentHashMap.newKeySet();
    private final Set<DatagramSocket> activeUdpSockets = ConcurrentHashMap.newKeySet();
    private ServerSocket listener;
    private Thread acceptThread;

    FragmentSocks5Engine(VpnService vpn, FragmentConfig config, DnsProxy dns) {
        this.vpn = vpn;
        this.config = config;
        this.dns = dns;
    }

    boolean start() {
        try {
            listener = new ServerSocket();
            listener.setReuseAddress(true);
            listener.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), config.socksPort));
            running.set(true);
            acceptThread = new Thread(() -> {
                while (running.get()) {
                    try {
                        final Socket client = listener.accept();
                        activeTcpSockets.add(client);
                        workers.execute(() -> handle(client));
                    } catch (SocketException e) {
                        if (running.get()) Log.e(TAG, "SOCKS5 accept failed", e);
                    } catch (Exception e) {
                        if (running.get()) Log.e(TAG, "SOCKS5 worker could not start", e);
                    }
                }
            }, "Frago-SOCKS5-Accept");
            acceptThread.start();
            Log.i(TAG, "SOCKS5 ready on 127.0.0.1:" + config.socksPort + " (TCP + UDP ASSOCIATE)");
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Cannot bind local SOCKS5 listener", e);
            stop();
            return false;
        }
    }

    private void handle(Socket client) {
        Socket remote = null;
        try (Socket local = client) {
            local.setTcpNoDelay(true);
            local.setSoTimeout(HANDSHAKE_TIMEOUT_MS);
            InputStream in = local.getInputStream();
            OutputStream out = local.getOutputStream();

            int version = in.read();
            int methodCount = in.read();
            if (version != 5 || methodCount < 1 || methodCount > 32) return;
            byte[] methods = readExact(in, methodCount);
            boolean noAuthOffered = false;
            for (byte method : methods) if ((method & 0xff) == 0) noAuthOffered = true;
            out.write(new byte[]{5, (byte) (noAuthOffered ? 0 : 0xff)});
            out.flush();
            if (!noAuthOffered) return;

            int requestVersion = in.read();
            int command = in.read();
            int reserved = in.read();
            int addressType = in.read();
            if (requestVersion != 5 || reserved != 0) {
                writeReply(out, 1);
                return;
            }
            Target target = readTarget(in, addressType);
            if (target == null) {
                writeReply(out, 8);
                return;
            }

            if (command == 3) { // UDP ASSOCIATE
                handleUdpAssociate(local, in, out);
                return;
            }
            if (command != 1) {
                writeReply(out, 7);
                return;
            }
            if (target.port < 1) {
                writeReply(out, 1);
                return;
            }

            List<InetAddress> addresses = resolveTarget(target.host);
            if (addresses.isEmpty()) {
                writeReply(out, 4);
                return;
            }

            IOException lastError = null;
            for (InetAddress address : addresses) {
                Socket candidate = new Socket();
                activeTcpSockets.add(candidate);
                if (!vpn.protect(candidate)) {
                    activeTcpSockets.remove(candidate);
                    candidate.close();
                    writeReply(out, 1);
                    throw new IOException("VpnService.protect(TCP) failed");
                }
                try {
                    candidate.connect(new InetSocketAddress(address, target.port), CONNECT_TIMEOUT_MS);
                    remote = candidate;
                    break;
                } catch (IOException e) {
                    lastError = e;
                    activeTcpSockets.remove(candidate);
                    close(candidate);
                }
            }
            if (remote == null) {
                writeConnectError(out, lastError);
                return;
            }

            remote.setTcpNoDelay(true);
            remote.setSoTimeout(0);
            local.setSoTimeout(0);
            writeReply(out, 0);

            final Socket connected = remote;
            Thread downstream = new Thread(() -> copyRemoteToClient(connected, local),
                    "Frago-TCP-RemoteToClient");
            downstream.start();
            try {
                copyClientToRemote(in, connected, target.host);
            } finally {
                // Preserve TCP half-close semantics: EOF from the app must be
                // forwarded to the remote server without discarding its reply.
                try { if (!connected.isOutputShutdown()) connected.shutdownOutput(); }
                catch (Exception ignored) { }
            }
            downstream.join();
        } catch (Exception e) {
            if (running.get() && !client.isClosed()) Log.w(TAG, "SOCKS5 session ended", e);
        } finally {
            if (remote != null) activeTcpSockets.remove(remote);
            activeTcpSockets.remove(client);
            close(remote);
            close(client);
        }
    }

    private Target readTarget(InputStream in, int addressType) throws IOException {
        String host;
        if (addressType == 1) {
            host = InetAddress.getByAddress(readExact(in, 4)).getHostAddress();
        } else if (addressType == 3) {
            int length = in.read();
            if (length < 1 || length > 255) return null;
            host = new String(readExact(in, length), "UTF-8");
        } else if (addressType == 4) {
            host = InetAddress.getByAddress(readExact(in, 16)).getHostAddress();
        } else {
            return null;
        }
        byte[] portBytes = readExact(in, 2);
        int port = ((portBytes[0] & 0xff) << 8) | (portBytes[1] & 0xff);
        return new Target(host, port);
    }

    private List<InetAddress> resolveTarget(String host) {
        try {
            if ("localhost".equalsIgnoreCase(host)) {
                return java.util.Collections.singletonList(InetAddress.getLoopbackAddress());
            }
            if (host.indexOf(':') >= 0) {
                return java.util.Collections.singletonList(InetAddress.getByName(host));
            }
            if (host.matches("[0-9]{1,3}(\\.[0-9]{1,3}){3}")) {
                return java.util.Collections.singletonList(InetAddress.getByName(host));
            }
            return dns.resolveIpv4(host);
        } catch (Exception e) {
            Log.w(TAG, "Target resolution failed: " + host, e);
            return java.util.Collections.emptyList();
        }
    }

    /** Runs one SOCKS5 UDP association until the TCP control socket is closed. */
    private void handleUdpAssociate(Socket control, InputStream controlIn, OutputStream controlOut) throws Exception {
        final DatagramSocket relay = new DatagramSocket(null);
        final DatagramSocket outbound = new DatagramSocket(null);
        activeUdpSockets.add(relay);
        activeUdpSockets.add(outbound);
        final AtomicBoolean alive = new AtomicBoolean(true);
        final AtomicReference<InetSocketAddress> peer = new AtomicReference<>();
        boolean success = false;
        try {
            relay.setReuseAddress(true);
            relay.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), 0));
            outbound.bind(new InetSocketAddress(0));
            outbound.setSoTimeout(600);
            outbound.setReceiveBufferSize(256 * 1024);
            if (!vpn.protect(outbound)) throw new IOException("VpnService.protect(UDP) failed");

            byte[] address = InetAddress.getByName("127.0.0.1").getAddress();
            int port = relay.getLocalPort();
            controlOut.write(new byte[]{5, 0, 0, 1, address[0], address[1], address[2], address[3],
                    (byte) ((port >>> 8) & 0xff), (byte) (port & 0xff)});
            controlOut.flush();
            control.setSoTimeout(1000);
            success = true;
            Log.d(TAG, "SOCKS5 UDP relay bound to 127.0.0.1:" + port);

            workers.execute(() -> udpClientLoop(relay, outbound, peer, alive));
            workers.execute(() -> udpResponseLoop(relay, outbound, peer, alive));

            while (running.get() && alive.get() && !control.isClosed()) {
                try {
                    int value = controlIn.read();
                    if (value < 0) break;
                    // RFC 1928 control stream is normally idle. Ignore unexpected keepalive bytes.
                } catch (SocketTimeoutException ignored) {
                    // Poll the TCP control connection so a closed association is released.
                }
            }
        } finally {
            alive.set(false);
            activeUdpSockets.remove(relay);
            activeUdpSockets.remove(outbound);
            relay.close();
            outbound.close();
            if (success) Log.d(TAG, "SOCKS5 UDP association closed");
        }
    }

    private void udpClientLoop(DatagramSocket relay, DatagramSocket outbound,
                               AtomicReference<InetSocketAddress> peer, AtomicBoolean alive) {
        byte[] buffer = new byte[UDP_PACKET_MAX];
        while (running.get() && alive.get() && !relay.isClosed() && !outbound.isClosed()) {
            try {
                DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                relay.receive(packet);
                InetSocketAddress source = new InetSocketAddress(packet.getAddress(), packet.getPort());
                if (!source.getAddress().isLoopbackAddress()) continue;
                InetSocketAddress knownPeer = peer.get();
                if (knownPeer == null) {
                    peer.compareAndSet(null, source);
                    knownPeer = peer.get();
                }
                if (knownPeer == null || !knownPeer.equals(source)) continue;

                UdpRequest request = parseUdpRequest(packet.getData(), packet.getOffset(), packet.getLength());
                if (request == null) continue;
                InetAddress destination = resolveUdpTarget(request.host);
                if (destination == null) continue;

                if (request.port == 53) {
                    byte[] answer = dns.resolveDnsMessage(request.payload);
                    if (answer != null) {
                        sendUdpReply(relay, knownPeer, destination, 53, answer);
                    }
                } else {
                    DatagramPacket outgoing = new DatagramPacket(request.payload, request.payload.length,
                            destination, request.port);
                    outbound.send(outgoing);
                }
            } catch (SocketTimeoutException ignored) {
            } catch (SocketException e) {
                if (alive.get() && running.get()) Log.w(TAG, "UDP relay socket error", e);
                break;
            } catch (Exception e) {
                if (alive.get() && running.get()) Log.w(TAG, "UDP request failed", e);
            }
        }
    }

    private void udpResponseLoop(DatagramSocket relay, DatagramSocket outbound,
                                 AtomicReference<InetSocketAddress> peer, AtomicBoolean alive) {
        byte[] buffer = new byte[UDP_PACKET_MAX];
        while (running.get() && alive.get() && !relay.isClosed() && !outbound.isClosed()) {
            try {
                DatagramPacket response = new DatagramPacket(buffer, buffer.length);
                outbound.receive(response);
                InetSocketAddress destinationPeer = peer.get();
                if (destinationPeer == null) continue;
                byte[] wrapped = makeUdpReply(response.getAddress(), response.getPort(),
                        response.getData(), response.getOffset(), response.getLength());
                relay.send(new DatagramPacket(wrapped, wrapped.length, destinationPeer));
            } catch (SocketTimeoutException ignored) {
            } catch (SocketException e) {
                if (alive.get() && running.get()) Log.w(TAG, "UDP response socket error", e);
                break;
            } catch (Exception e) {
                if (alive.get() && running.get()) Log.w(TAG, "UDP response failed", e);
            }
        }
    }

    private InetAddress resolveUdpTarget(String host) {
        try {
            if (host.indexOf(':') >= 0 || host.matches("[0-9]{1,3}(\\.[0-9]{1,3}){3}")) {
                return InetAddress.getByName(host);
            }
            List<InetAddress> addresses = dns.resolveIpv4(host);
            return addresses.isEmpty() ? null : addresses.get(0);
        } catch (Exception e) {
            return null;
        }
    }

    private static final class Target {
        final String host;
        final int port;
        Target(String host, int port) { this.host = host; this.port = port; }
    }

    private static final class UdpRequest {
        final String host;
        final int port;
        final byte[] payload;
        UdpRequest(String host, int port, byte[] payload) {
            this.host = host; this.port = port; this.payload = payload;
        }
    }

    private UdpRequest parseUdpRequest(byte[] data, int offset, int length) throws Exception {
        if (length < 10 || data[offset] != 0 || data[offset + 1] != 0 || data[offset + 2] != 0) return null;
        int p = offset + 3;
        int end = offset + length;
        int atyp = data[p++] & 0xff;
        String host;
        if (atyp == 1) {
            if (p + 4 + 2 > end) return null;
            host = InetAddress.getByAddress(copyOfRange(data, p, 4)).getHostAddress();
            p += 4;
        } else if (atyp == 3) {
            if (p + 1 > end) return null;
            int n = data[p++] & 0xff;
            if (n < 1 || p + n + 2 > end) return null;
            host = new String(data, p, n, "UTF-8");
            p += n;
        } else if (atyp == 4) {
            if (p + 16 + 2 > end) return null;
            host = InetAddress.getByAddress(copyOfRange(data, p, 16)).getHostAddress();
            p += 16;
        } else {
            return null;
        }
        int port = ((data[p] & 0xff) << 8) | (data[p + 1] & 0xff);
        p += 2;
        if (port < 1 || p > end) return null;
        byte[] payload = new byte[end - p];
        java.lang.System.arraycopy(data, p, payload, 0, payload.length);
        return new UdpRequest(host, port, payload);
    }

    private static byte[] makeUdpReply(InetAddress source, int port, byte[] payload, int offset, int length)
            throws IOException {
        byte[] address = source.getAddress();
        int atyp = address.length == 16 ? 4 : 1;
        byte[] result = new byte[3 + 1 + address.length + 2 + length];
        int p = 0;
        result[p++] = 0; result[p++] = 0; result[p++] = 0;
        result[p++] = (byte) atyp;
        java.lang.System.arraycopy(address, 0, result, p, address.length); p += address.length;
        result[p++] = (byte) ((port >>> 8) & 0xff);
        result[p++] = (byte) (port & 0xff);
        java.lang.System.arraycopy(payload, offset, result, p, length);
        return result;
    }

    private static void sendUdpReply(DatagramSocket relay, InetSocketAddress peer,
                                     InetAddress source, int sourcePort, byte[] payload) throws IOException {
        byte[] wrapped = makeUdpReply(source, sourcePort, payload, 0, payload.length);
        relay.send(new DatagramPacket(wrapped, wrapped.length, peer));
    }

    private static byte[] copyOfRange(byte[] source, int offset, int length) {
        byte[] out = new byte[length];
        java.lang.System.arraycopy(source, offset, out, 0, length);
        return out;
    }

    /** TLS path: ClientHello bytes are split into independently framed TLS records. */
    private void copyClientToRemote(InputStream in, Socket remote, String destinationHost) throws Exception {
        OutputStream out = remote.getOutputStream();
        byte[] firstRecord = readFirstTlsRecord(in);
        if (firstRecord != null) {
            String sni = TlsHelloFragmenter.extractSni(firstRecord);
            boolean shouldFragment = config.shouldFragmentHost(destinationHost)
                    && config.shouldFragmentSni(sni);
            if (shouldFragment && TlsHelloFragmenter.isClientHelloRecord(firstRecord)) {
                int chunks = TlsHelloFragmenter.writeFragments(out, firstRecord,
                        config.minLength, config.maxLength, config.minInterval, config.maxInterval);
                Log.i(TAG, "TLS ClientHello fragmented: destination=" + destinationHost
                        + ", sni=" + (sni == null ? "unknown" : sni)
                        + ", records=" + chunks
                        + ", length=" + config.minLength + "-" + config.maxLength
                        + ", interval=" + config.minInterval + "-" + config.maxInterval + "ms");
            } else {
                out.write(firstRecord);
                out.flush();
                if (TlsHelloFragmenter.isClientHelloRecord(firstRecord)) {
                    Log.i(TAG, "TLS ClientHello passed without Fragment: destination=" + destinationHost
                            + ", sni=" + (sni == null ? "unknown" : sni));
                }
            }
        }
        byte[] buffer = new byte[16 * 1024];
        int count;
        while ((count = in.read(buffer)) != -1) {
            out.write(buffer, 0, count);
            out.flush();
        }
    }

    private byte[] readFirstTlsRecord(InputStream in) throws IOException {
        int first = in.read();
        if (first < 0) return null;
        byte[] header = new byte[5];
        header[0] = (byte) first;
        readFully(in, header, 1, 4);
        int recordLength = ((header[3] & 0xff) << 8) | (header[4] & 0xff);
        if ((header[0] & 0xff) != 22 || (header[1] & 0xff) != 3
                || recordLength < 1 || recordLength > 18432) return header;
        byte[] payload = readExact(in, recordLength);
        byte[] record = new byte[5 + recordLength];
        java.lang.System.arraycopy(header, 0, record, 0, 5);
        java.lang.System.arraycopy(payload, 0, record, 5, recordLength);
        return record;
    }

    private void copyRemoteToClient(Socket remote, Socket client) {
        try {
            InputStream in = remote.getInputStream();
            OutputStream out = client.getOutputStream();
            byte[] buffer = new byte[16 * 1024];
            int count;
            while ((count = in.read(buffer)) != -1) {
                out.write(buffer, 0, count);
                out.flush();
            }
        } catch (Exception e) {
            Log.w(TAG, "TCP remote-to-client stopped", e);
        } finally {
            // A remote FIN closes only the response direction. The client may
            // still have request bytes to send, so do not close the whole socket.
            try { if (!client.isOutputShutdown()) client.shutdownOutput(); }
            catch (Exception ignored) { }
        }
    }

    private static void writeConnectError(OutputStream out, IOException error) throws IOException {
        if (error instanceof UnknownHostException) writeReply(out, 4);
        else if (error instanceof NoRouteToHostException) writeReply(out, 3);
        else if (error instanceof ConnectException) writeReply(out, 5);
        else if (error instanceof SocketTimeoutException) writeReply(out, 6);
        else writeReply(out, 1);
    }

    private static byte[] readExact(InputStream in, int length) throws IOException {
        byte[] result = new byte[length];
        readFully(in, result, 0, length);
        return result;
    }

    private static void readFully(InputStream in, byte[] buffer, int offset, int length) throws IOException {
        while (length > 0) {
            int count = in.read(buffer, offset, length);
            if (count < 0) throw new EOFException("Unexpected end of SOCKS5/TLS data");
            offset += count;
            length -= count;
        }
    }

    private static void writeReply(OutputStream out, int result) throws IOException {
        out.write(new byte[]{5, (byte) result, 0, 1, 0, 0, 0, 0, 0, 0});
        out.flush();
    }

    private static void close(Socket socket) {
        if (socket != null) try { socket.close(); } catch (Exception ignored) { }
    }

    void stop() {
        running.set(false);
        if (listener != null) try { listener.close(); } catch (Exception ignored) { }
        for (Socket socket : activeTcpSockets) close(socket);
        for (DatagramSocket socket : activeUdpSockets) {
            try { socket.close(); } catch (Exception ignored) { }
        }
        activeTcpSockets.clear();
        activeUdpSockets.clear();
        workers.shutdownNow();
    }
}
